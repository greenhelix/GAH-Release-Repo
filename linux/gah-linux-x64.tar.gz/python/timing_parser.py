#!/usr/bin/env python3
"""
XTS 결과 디렉토리에서 정확한 테스트 시간 데이터를 추출한다. (v1.1.0~)

목적: invocation_summary.txt + test_result.xml <Run> 에서 KPI 기반 시간 데이터를
      뽑아 test_sessions / test_modules 의 정밀 시간 컬럼을 채운다.

용어:
  [총 작업량]     = 모든 모듈 시간 합. 디바이스 수와 무관 (일의 총량)
  [실제 걸린 시간] = <Run> 세그먼트 합. 디바이스 늘리면 줄어듦 (체감 시간)

데이터 출처:
  - 실제 걸린 시간  : test_result.xml 의 <Run start/end> (최초 풀런 + 재시도 N)
                     ※ invocation_summary 의 "Total Run time"은 리포트 생성 시간이라 사용 안 함
  - 모듈별 시간/재시도 : invocation_summary.txt
       · Consumed Time          → consumed_ms (prep+실행+clean 전체)
       · TOP Slow Modules       → exec_ms(순수 실행), test_count
       · Modules Retries Info   → retry_ms / retry_success / retry_failure
       · Total aggregated ...   → total_work_ms
       · Total Retry Time       → total_retry_ms

사용법:
  # 1) 파싱 결과를 JSON으로 출력 (DB 접근 없음, 검증용)
  python3 timing_parser.py /path/to/results/2026.05.22_17.36.33.746_3142

  # 2) DB의 매칭 세션에 시간 컬럼 적재 (psycopg2 필요 → tool_observer venv 사용)
  set -a; . ./.env.agent; set +a          # DB_HOST/DB_USER/DB_PASSWORD ...
  python/tool_observer/venv/bin/python3 python/timing_parser.py <result_dir> --upload

  ※ 파싱/JSON 모드(1번)는 stdlib만 쓰므로 시스템 python3로도 동작한다.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path


# ============================================================
# 시간 문자열 파서
# ============================================================
_UNIT_MS = {"h": 3_600_000, "m": 60_000, "s": 1_000}


def parse_duration_ms(text: str) -> int:
    """'17h 15m 30s', '5m 3s', '53s', '78 ms' → 밀리초(int) 변환.

    ms는 'm'(분)과 헷갈리므로 먼저 떼어낸 뒤 h/m/s를 처리한다.
    """
    text = text.strip()
    total = 0
    m = re.search(r"(\d+)\s*ms\b", text)
    if m:
        total += int(m.group(1))
        text = text[: m.start()] + text[m.end():]
    for value, unit in re.findall(r"(\d+)\s*([hms])\b", text):
        total += int(value) * _UNIT_MS[unit]
    return total


def split_abi_name(token_str: str) -> tuple[str, str]:
    """'armeabi-v7a CtsDeqpTestCases[instant]' → ('armeabi-v7a', 'CtsDeqp...[instant]')

    abi는 항상 첫 공백 토큰. 나머지가 모듈명(접미사 [instant]/27 등 포함).
    """
    parts = token_str.strip().split(None, 1)
    if len(parts) == 2:
        return parts[0], parts[1]
    return "", parts[0]  # abi 없는 경우(TVTS 등)


# ============================================================
# invocation_summary.txt 파서
# ============================================================
# "    armeabi-v7a CtsDeqpTestCases: 17h 15m 30s"
_RE_CONSUMED = re.compile(r"^\s+(\S.*?):\s+([\dhms ]+?)\s*$")
# "    arm64-v8a CtsTimeTestCases: 0.52 tests/sec [28 tests / 53803 msec]"
_RE_SLOW = re.compile(
    r"^\s+(\S.*?):\s+[\d.]+\s+tests/sec\s+\[(\d+)\s+tests\s*/\s*(\d+)\s+msec\]"
)
# 재시도 블록 헤더: "    arm64-v8a CtsAccessibilityServiceTestCases:"  (값 없이 콜론으로 끝)
_RE_RETRY_HEAD = re.compile(r"^\s+(\S.*?):\s*$")
_RE_RETRY_SUCCESS = re.compile(r"Retry Success.*?=\s*(\d+)")
_RE_RETRY_FAILURE = re.compile(r"Retry Failure.*?=\s*(\d+)")
_RE_RETRY_TIME = re.compile(r"Retry Time\s*=\s*(.+?)\s*$")


def parse_invocation_summary(path: Path) -> dict:
    """invocation_summary.txt → {modules: {(abi,name): {...}}, totals: {...}}"""
    modules: dict[tuple[str, str], dict] = {}

    def mod(key: tuple[str, str]) -> dict:
        return modules.setdefault(
            key,
            {
                "abi": key[0], "name": key[1],
                "consumed_ms": None, "exec_ms": None, "test_count": None,
                "retry_ms": None, "retry_success": None, "retry_failure": None,
            },
        )

    section = None          # 현재 섹션
    retry_key = None        # 재시도 블록에서 현재 모듈 키
    totals = {"total_work_ms": None, "total_retry_ms": None}

    with open(path, "r", errors="replace") as f:
        for line in f:
            stripped = line.strip()

            # ── 섹션 전환 ──
            if "Consumed Time" in line and stripped.startswith("="):
                section = "consumed"; continue
            if "Slow Modules" in line:
                section = "slow"; continue
            if "Modules Preparation Times" in line:
                section = "prep"; continue
            if "Modules Retries Information" in line:
                section = "retry"; retry_key = None; continue
            if stripped.startswith("Total aggregated tests run time"):
                totals["total_work_ms"] = parse_duration_ms(stripped.split(":", 1)[1])
                section = None; continue
            if stripped.startswith("Total Retry Time"):
                totals["total_retry_ms"] = parse_duration_ms(stripped.split("=", 1)[1])
                continue

            # ── 섹션별 파싱 ──
            if section == "consumed":
                m = _RE_CONSUMED.match(line)
                if m:
                    abi, name = split_abi_name(m.group(1))
                    mod((abi, name))["consumed_ms"] = parse_duration_ms(m.group(2))

            elif section == "slow":
                m = _RE_SLOW.match(line)
                if m:
                    abi, name = split_abi_name(m.group(1))
                    d = mod((abi, name))
                    d["test_count"] = int(m.group(2))
                    d["exec_ms"] = int(m.group(3))

            elif section == "retry":
                ms = _RE_RETRY_SUCCESS.search(line)
                mf = _RE_RETRY_FAILURE.search(line)
                mt = _RE_RETRY_TIME.search(line)
                if ms and retry_key:
                    mod(retry_key)["retry_success"] = int(ms.group(1))
                elif mf and retry_key:
                    mod(retry_key)["retry_failure"] = int(mf.group(1))
                elif mt and retry_key:
                    mod(retry_key)["retry_ms"] = parse_duration_ms(mt.group(1))
                else:
                    h = _RE_RETRY_HEAD.match(line)
                    if h:
                        retry_key = split_abi_name(h.group(1))

    return {"modules": modules, "totals": totals}


# ============================================================
# test_result.xml <Run> 파서  (647MB 대비 청크 읽기)
# ============================================================
_RE_RUN = re.compile(r'<Run\s+start="(\d+)"\s+end="(\d+)"')
_RE_CMDARGS = re.compile(r'command_line_args="([^"]*)"')
_RE_IS_RETRY = re.compile(r'is_retry_result="(true|false)"')


def parse_run_segments(xml_path: Path, max_bytes: int = 8_000_000) -> dict:
    """XML 상단의 <Run start/end> 들을 추출. <Module 등장 전까지만 읽는다."""
    buf = ""
    read = 0
    with open(xml_path, "r", errors="replace") as f:
        while read < max_bytes:
            chunk = f.read(1_000_000)
            if not chunk:
                break
            read += len(chunk)
            buf += chunk
            if "<Module" in buf:           # 모듈 결과 시작 = <Run> 블록 끝
                buf = buf.split("<Module", 1)[0]
                break

    runs = [(int(s), int(e)) for s, e in _RE_RUN.findall(buf)]
    cmd = _RE_CMDARGS.search(buf)
    command_line_args = cmd.group(1) if cmd else None
    rr = _RE_IS_RETRY.search(buf)
    is_retry_result = (rr.group(1) == "true") if rr else False

    shard_count = 1
    if command_line_args:
        m = re.search(r"--shard-count[,=\s]+(\d+)", command_line_args)
        if m:
            shard_count = int(m.group(1))

    return {
        "runs": runs,
        "run_count": len(runs),
        "first_run_ms": (runs[0][1] - runs[0][0]) if runs else None,
        "real_elapsed_ms": sum(e - s for s, e in runs) if runs else None,
        "command_line_args": command_line_args,
        "shard_count": shard_count,
        "is_retry_result": is_retry_result,
    }


# ============================================================
# 통합 + KPI 계산
# ============================================================
def parse_result_dir(result_dir: Path) -> dict:
    inv = result_dir / "invocation_summary.txt"
    xml = result_dir / "test_result.xml"
    if not inv.exists():
        raise FileNotFoundError(f"invocation_summary.txt 없음: {inv}")
    if not xml.exists():
        raise FileNotFoundError(f"test_result.xml 없음: {xml}")

    summary = parse_invocation_summary(inv)
    run = parse_run_segments(xml)

    session = {
        "result_dir": result_dir.name,
        "real_elapsed_ms": run["real_elapsed_ms"],
        "first_run_ms": run["first_run_ms"],
        "run_count": run["run_count"],
        "total_work_ms": summary["totals"]["total_work_ms"],
        "total_retry_ms": summary["totals"]["total_retry_ms"],
        "shard_count": run["shard_count"],
        "command_line_args": run["command_line_args"],
        "is_retry_result": run["is_retry_result"],
    }
    modules = list(summary["modules"].values())

    # ── KPI (표시용, DB 저장 안 함) ──
    kpi = {}
    work = session["total_work_ms"]
    elapsed = session["real_elapsed_ms"]
    first = session["first_run_ms"]
    n = session["shard_count"] or 1
    if work and elapsed:
        kpi["speedup_overall"] = round(work / elapsed, 2)
        kpi["efficiency_overall"] = round(work / elapsed / n, 2)
    if work and first:
        kpi["speedup_first_run"] = round(work / first, 2)
        kpi["efficiency_first_run"] = round(work / first / n, 2)
    if session["total_retry_ms"] and first:
        # [주의] 재시도 병합 리포트(is_retry_result=true)는 Retry Time이 전체 시간과
        #        같아져 낭비율이 무의미하다. 신뢰 가능한 값이 아니면 경고만 남긴다.
        if session["is_retry_result"]:
            kpi["retry_waste_ratio"] = None
            kpi["retry_note"] = "재시도 병합 리포트라 retry_ms 신뢰 불가 (전체 시간과 동일)"
        else:
            kpi["retry_waste_ratio"] = round(session["total_retry_ms"] / first, 3)

    return {"session": session, "modules": modules, "kpi": kpi}


# ============================================================
# DB 적재 (psycopg2는 --upload 시에만 import)
# ============================================================
def upload(parsed: dict) -> None:
    import psycopg2  # 지연 import: 파싱/JSON 모드는 stdlib만으로 동작

    conn = psycopg2.connect(
        host=os.environ.get("DB_HOST", "localhost"),
        port=int(os.environ.get("DB_PORT", 5432)),
        dbname=os.environ.get("DB_NAME", "gah"),
        user=os.environ.get("DB_USER", "gah_user"),
        password=os.environ.get("DB_PASSWORD", ""),
    )
    s = parsed["session"]
    try:
        with conn, conn.cursor() as cur:
            # 결과 디렉토리 이름으로 세션 매칭 (Flutter가 result_dir_path에 저장)
            cur.execute(
                "SELECT id FROM test_sessions WHERE result_dir_path LIKE %s ORDER BY created_at DESC LIMIT 1",
                (f"%{s['result_dir']}%",),
            )
            row = cur.fetchone()
            if not row:
                print(f"[경고] 매칭 세션 없음 (result_dir_path LIKE %{s['result_dir']}%) — 적재 건너뜀")
                print("       Flutter 업로드로 세션이 먼저 생성돼야 시간 컬럼을 채울 수 있음")
                return
            session_id = row[0]

            cur.execute(
                """
                UPDATE test_sessions SET
                    real_elapsed_ms = %s, first_run_ms = %s, run_count = %s,
                    total_work_ms = %s, total_retry_ms = %s
                WHERE id = %s
                """,
                (s["real_elapsed_ms"], s["first_run_ms"], s["run_count"],
                 s["total_work_ms"], s["total_retry_ms"], session_id),
            )

            updated = 0
            for m in parsed["modules"]:
                cur.execute(
                    """
                    UPDATE test_modules SET
                        consumed_ms = COALESCE(%s, consumed_ms),
                        exec_ms = %s, total_tests = COALESCE(%s, total_tests),
                        retry_ms = %s, retry_success = %s, retry_failure = %s
                    WHERE session_id = %s AND name = %s AND abi = %s
                    """,
                    (m["consumed_ms"], m["exec_ms"], m["test_count"],
                     m["retry_ms"], m["retry_success"], m["retry_failure"],
                     session_id, m["name"], m["abi"]),
                )
                updated += cur.rowcount
            print(f"[완료] 세션 {session_id} 갱신, 모듈 {updated}/{len(parsed['modules'])}개 매칭")
    finally:
        conn.close()


def _backfill_batch(parent: Path) -> int:
    """[parent] 하위에서 invocation_summary.txt 를 가진 모든 결과 디렉토리를
    찾아 DB 매칭 세션에 시간 컬럼을 일괄 적재한다. (과거 세션 백필용)

    테스트 호스트에서 실행:
      python timing_parser.py /path/to/android-xts/results --batch
    """
    dirs = sorted({p.parent for p in parent.rglob("invocation_summary.txt")})
    if not dirs:
        print(f"[경고] invocation_summary.txt 를 가진 디렉토리 없음: {parent}")
        return 1
    print(f"[백필] 대상 디렉토리 {len(dirs)}개")
    ok = 0
    for d in dirs:
        try:
            parsed = parse_result_dir(d)
            upload(parsed)
            ok += 1
        except Exception as e:  # 한 건 실패가 전체를 막지 않도록
            print(f"[건너뜀] {d.name}: {e}")
    print(f"[백필 완료] {ok}/{len(dirs)} 처리")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="XTS 결과 디렉토리 시간 데이터 추출")
    ap.add_argument("result_dir", help="결과 디렉토리(또는 --batch 시 상위 디렉토리)")
    ap.add_argument("--upload", action="store_true", help="DB 매칭 세션에 시간 컬럼 적재")
    ap.add_argument("--batch", action="store_true",
                    help="result_dir 하위의 모든 결과 폴더를 찾아 일괄 백필(자동 --upload)")
    ap.add_argument("--modules", action="store_true", help="JSON에 모듈 상세 포함")
    args = ap.parse_args()

    if args.batch:
        return _backfill_batch(Path(args.result_dir))

    parsed = parse_result_dir(Path(args.result_dir))

    if args.upload:
        upload(parsed)
    else:
        out = {"session": parsed["session"], "kpi": parsed["kpi"],
               "module_count": len(parsed["modules"])}
        if args.modules:
            out["modules"] = parsed["modules"]
        print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())

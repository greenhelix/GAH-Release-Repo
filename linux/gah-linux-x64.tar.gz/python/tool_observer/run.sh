#!/bin/bash
# Tool Observer 자동 실행 스크립트 (cron 등록용)
#
# 사전 준비 (최초 1회):
#   python setup_auth.py
#
# 세션 만료 시: 관리자(alert_to)에게 알림 메일이 발송됩니다.
#   직접 setup_auth.py를 실행해 재인증하세요.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 브라우저 프로필 없으면 조기 종료
if [ ! -d "auth/browser_profile/Default" ]; then
    echo "[run.sh] auth/browser_profile 없음 — 먼저 실행: python setup_auth.py"
    exit 1
fi

# 감시 실행 (세션 만료 시 경고 메일 발송)
python cli.py run --enrich

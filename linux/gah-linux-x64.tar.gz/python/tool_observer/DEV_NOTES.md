# Tool Observer 개발 히스토리

## 2026-05-07 — Ubuntu 서버 이전 및 근본 구조 개선

### 배경
- WSL 환경에서 운영 중 세션이 매일 만료되는 문제 반복
- setup_auth.py가 Windows Chrome CDP 방식에 의존 → 불안정
- Ubuntu 20.04 GUI 데스크탑 서버로 이전 결정

---

### 주요 변경사항

#### 1. setup_auth.py 전면 재작성
- **구 방식**: Windows Chrome CDP(디버그 포트 9222) 연결 → 쿠키 추출 → auth.json 저장
- **신 방식**: Ubuntu에서 Playwright Chromium GUI 직접 실행 (headless=False)
  - `launch_persistent_context`로 `auth/browser_profile/`에 영구 저장
  - 수동 로그인 후 Enter → 완료
- SingletonLock 자동 제거 로직 추가 (다른 머신에서 복사 시 잔여 락 파일 처리)

#### 2. tool_observer.py — 세션 방식 변경
- **구 방식**: `launch(headless=True)` + `storage_state=auth.json` (쿠키만)
  - 문제: Google이 매일 세션 무효화 (브라우저 fingerprint 없음)
- **신 방식**: `launch_persistent_context(PROFILE_DIR, headless=True)`
  - 브라우저 프로필 전체 유지 → 세션 수명 대폭 증가
- auth.json 의존성 완전 제거
- 세션 만료 자동 재인증 시도 코드 제거 (GUI 없이 불가)
- SingletonLock 자동 제거 로직 추가

#### 3. 이메일 발송 — SMTP → Gmail REST API
- **이유**: 서버 호스팅 환경에서 아웃바운드 SMTP 포트(465/587) 차단
- **신 방식**: Gmail REST API (HTTPS 443 포트)
  - `credentials.json`: Google Cloud Console OAuth2 클라이언트 ID
  - `auth/gmail_token.json`: 최초 인증 후 자동 저장, 자동 갱신
  - 최초 실행 시 브라우저 OAuth2 인증 팝업 → 이후 자동
- 의존성 추가: `google-api-python-client`, `google-auth-oauthlib`, `google-auth-httplib2`

#### 4. 이메일 레이아웃 개선
- 변경 감지 이메일: 변경 카드 + 하단 전체 현황 테이블 통합
- 변경 없음 이메일: 전체 현황 테이블 (기존 유지)
- 현황 테이블: 값 없을 때 "미발견" → "업데이트 안됨"으로 변경
- `_build_status_table_html()` 헬퍼 분리 (두 이메일 타입 공통 사용)

#### 5. dry-run 버그 수정
- `--dry-run` 실행 시에도 state.json을 저장하던 버그 수정
- dry-run은 state 변경 없이 감지만 수행

#### 6. run.sh 변경
- 체크 대상: `auth/auth.json` 존재 여부 → `auth/browser_profile/Default` 디렉토리 존재 여부

---

### 파일 구조
```
tool_observer/
├── tool_observer.py     # 메인 감시 스크립트
├── setup_auth.py        # 세션 설정 (Ubuntu GUI, 수동 로그인)
├── run.sh               # cron 실행 래퍼
├── targets.yaml         # 감시 대상 설정
├── config.yaml          # SMTP from/to 설정 (gitignore)
├── credentials.json     # Gmail API OAuth2 클라이언트 (gitignore)
├── state.json           # 이전 상태 저장 (비교용)
├── observer.log         # 실행 로그
└── auth/
    ├── browser_profile/ # Playwright 영구 프로필 (gitignore)
    └── gmail_token.json # Gmail API 토큰 (gitignore)
```

---

### 운영 방법

#### cron 등록 (매일 09:00 KST)
```
0 9 * * * cd ~/google/tool_observer && venv/bin/python tool_observer.py >> observer.log 2>&1
```

#### 세션 만료 시 (파트너 포털 접근 불가)
```bash
cd ~/google/tool_observer
source venv/bin/activate
python setup_auth.py
# GUI 창에서 파트너 포털 계정으로 로그인 → Enter
```

#### Gmail 토큰 만료 시 (드물게 발생)
```bash
rm auth/gmail_token.json
python tool_observer.py --test-email
# 브라우저 OAuth2 인증 팝업 → 완료
```

#### 테스트 실행
```bash
python tool_observer.py --dry-run     # 크롤링만, 이메일/상태 저장 없음
python tool_observer.py --test-email  # 전체 실행 + 강제 메일 발송
```

#### 수신자 추가
`config.yaml`의 `to` 항목에 추가:
```yaml
smtp:
  from: innoiktest@gmail.com
  to:
    - dlrghks4444@gmail.com
    - 추가할이메일@example.com
```

---

### 알려진 이슈
- STS URL(`https://docs.partner.android.com/security/test-suite/latest-sts-binary`) — 404 가능성 있음, 파트너 포털에서 확인 필요
- `setup_auth.py` 실행 시 서버 디스플레이에서 실행해야 함 (SSH X-forwarding으로도 가능)

#!/bin/bash
# Tool Observer 실패 알림 — 클릭형 재인증 프롬프트.
# tool-observer-alert.service의 ExecStart로 실행된다 (OnFailure 트리거).
zenity --question \
    --title="Tool Observer" \
    --text="Tool Observer 실행이 실패했습니다.\n\n세션 또는 Gmail 인증이 만료되었을 가능성이 높습니다.\n지금 재인증을 시작할까요?\n\n로그 확인: journalctl -u tool-observer-agent.service" \
    --ok-label="재인증 시작" \
    --cancel-label="나중에" \
    --width=400

if [ $? -eq 0 ]; then
    gnome-terminal --title="Tool Observer 재인증" -- "$(dirname "$0")/reauth.sh"
fi

#!/usr/bin/env python3
# Python 3.8 호환: dict[str, str] 등 런타임 평가 없이 문자열로 처리
from __future__ import annotations

"""
Tool Observer CLI — XTS 도구 업데이트 감시 (단일 진입점).

실행 방법:
  python cli.py run                 # 전체 감시
  python cli.py run --dry-run       # 변경 감지만 (이메일/DB쓰기 미발송)
  python cli.py run --id cts        # 특정 대상만 실행
  python cli.py run --enrich        # 선택적 Claude 진단 포함
  python cli.py run --json          # 마지막에 RunResult를 JSON 한 줄로 출력
  python cli.py status              # 최근 실행 1건 (DB만 읽음, 브라우저 안 띄움)
  python cli.py history --limit 10  # 최근 실행 N건
  python cli.py doctor              # 세션/추출만 확인 (DB쓰기·이메일 없음)
  python cli.py test-email          # 이메일 템플릿 레이아웃 확인용 강제 발송

최초 실행 전: python setup_auth.py 로 구글 세션 저장 필요.
"""

import argparse
import asyncio
import json as json_lib
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml
from playwright.async_api import async_playwright

from agent import enrich as enrich_mod
from core import browser, classify
from core import diff as diffmod
from core import email as email_mod
from core import db, snapshot
from core.dotenv import load_env_files
from core.log import LOG_FILE, log, log_err, log_warn
from core.types import RunResult, ToolOutcome, ToolRunOutcome
from tools import TOOL_REGISTRY

BASE_DIR = Path(__file__).parent
CONFIG_FILE = BASE_DIR / "config.yaml"
TARGETS_FILE = BASE_DIR / "targets.yaml"

SETUP_AUTH_HINT = (
    "DB PC GUI 화면에서 (SSH만으론 로그인 창이 안 뜨므로 안 됨):\n"
    "    cd /home/kani/xts/gah_code/python/tool_observer\n"
    "    ./venv/bin/python setup_auth.py"
)


def load_yaml(path: Path) -> dict:
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def _load_config() -> dict:
    return load_yaml(CONFIG_FILE) if CONFIG_FILE.exists() else {}


def _print_summary(result: RunResult, json_output: bool) -> None:
    tool_line = "  ".join(f"{o.tool_id}={o.outcome.value}" for o in result.tool_outcomes)
    print("\n==== RUN SUMMARY ====")
    print(f"status: {result.status}")
    print(f"tools: {tool_line}")
    print(f"new_versions: {result.total_new_versions}")
    print(f"db_write: {'ok' if result.db_write_ok else 'FAIL — ' + str(result.db_write_error)}")
    email_state = "skipped(dry-run)" if result.dry_run else (
        "sent" if result.email_sent else f"FAILED — {result.email_error}"
    )
    print(f"email: {email_state}")
    print(f"duration: {result.duration_sec:.1f}s")
    print("======================")

    if result.auth_failed_tools:
        print(f"\n[조치] 세션 만료 의심 ({', '.join(result.auth_failed_tools)}) — {SETUP_AUTH_HINT}\n")
    elif result.extraction_failed_tools:
        print(
            f"\n[조치] 페이지 구조 변경 가능성 ({', '.join(result.extraction_failed_tools)})"
            f" — 이 출력을 그대로 Claude에게 붙여넣어 주세요.\n"
        )
    elif result.status == "db_unavailable":
        print("\n[조치] PostgreSQL 상태 확인: sudo systemctl status postgresql\n")

    if json_output:
        print(json_lib.dumps(result.to_dict(), ensure_ascii=False, default=str))


async def run_once(
    target_ids: list[str] | None, dry_run: bool, test_email: bool,
    do_enrich: bool, json_output: bool,
) -> RunResult | None:
    load_env_files()
    config = _load_config()
    targets_all: list[dict] = load_yaml(TARGETS_FILE)["targets"]

    if target_ids:
        targets = [t for t in targets_all if t["id"] in target_ids]
        if not targets:
            log_err(f"대상 ID 미발견: {target_ids}")
            return None
    else:
        targets = targets_all

    started_at = datetime.now(timezone.utc)
    log("=" * 60)
    log(f"Tool Observer 시작 — 대상 {len(targets)}개{'  [dry-run]' if dry_run else ''}")

    # ── DB 우선 조회: 이게 유일한 "신규 버전인지" 판단 기준 ──────────────────
    known_versions = db.read_known_versions(config)
    if known_versions is None:
        err_msg = "xts_tool_versions 조회 실패 — DB 연결 불가로 추정. observer.log/PostgreSQL 상태 확인 필요."
        log_err(err_msg)
        # 데스크톱 알림은 tool-observer-alert.service(zenity, OnFailure)가
        # exit_code=1로 단일 창 처리한다 — 여기서 또 notify_desktop을 쏘면 팝업이 중복됨
        finished_at = datetime.now(timezone.utc)
        result = RunResult(
            started_at=started_at.isoformat(), finished_at=finished_at.isoformat(),
            duration_sec=(finished_at - started_at).total_seconds(), dry_run=dry_run,
            status="db_unavailable", db_write_ok=False, db_write_error=err_msg, exit_code=1,
        )
        if not dry_run and config:
            try:
                email_mod.send_email(config, [], db_error=err_msg)
                result.email_sent = True
            except Exception as e:
                result.email_error = str(e)
        log("DB 조회 실패로 스크래핑 건너뜀 — 실행 종료")
        _print_summary(result, json_output)
        return result

    display_snapshot = snapshot.read()
    tool_outcomes: list[ToolRunOutcome] = []

    async with async_playwright() as pw:
        context = await browser.launch_context(pw)
        page = await context.new_page()

        auth_targets = [t for t in targets if t.get("auth_required", False)]
        skipped_names = set(await browser.check_session(page, auth_targets))

        for target in targets:
            tid = target["id"]
            log(f"\n{'─'*50}")
            log(f"[{tid.upper()}] {target['name']}")

            defn = TOOL_REGISTRY.get(tid)
            if not defn:
                log_warn(f"  등록된 도구 정의 없음: {tid}")
                continue

            if target["name"] in skipped_names:
                log("  세션 만료로 건너뜀")
                tool_outcomes.append(ToolRunOutcome(
                    tool_id=tid, tool_name=target["name"], outcome=ToolOutcome.SKIPPED,
                ))
                continue

            try:
                extraction = await defn.extract(page, target)
            except Exception as e:
                log_err(f"  추출 실패: {e}")
                log_err(traceback.format_exc())
                tool_outcomes.append(ToolRunOutcome(
                    tool_id=tid, tool_name=target["name"],
                    outcome=ToolOutcome.EXTRACTION_FAILED, error=str(e),
                ))
                continue

            outcome = classify.classify_outcome(extraction.values, target.get("auth_required", False))
            extraction.outcome = outcome

            if outcome != ToolOutcome.OK:
                label = "인증 실패 의심" if outcome == ToolOutcome.AUTH_FAILED else "추출 실패"
                log_warn(f"  ⚠️ {label} (값 전부 미발견) — 스냅샷 유지, 비교 생략")
                tool_outcomes.append(ToolRunOutcome(
                    tool_id=tid, tool_name=target["name"], outcome=outcome, extraction=extraction,
                ))
                continue

            known = known_versions.get(defn.suite_name, {})
            new_versions = diffmod.decide_new_versions(
                defn.normalize_version, extraction.values, known, force=test_email,
                release_dates=extraction.release_dates,
            )
            display_snapshot[tid] = {
                "last_updated": extraction.last_updated,
                "versions": extraction.values,
                "checked_at": extraction.checked_at,
            }

            if new_versions:
                log(f"  ✅ 변경 {len(new_versions)}건 감지")
            else:
                log("  — 변경 없음")

            tool_outcomes.append(ToolRunOutcome(
                tool_id=tid, tool_name=target["name"], outcome=outcome,
                extraction=extraction, new_versions=new_versions,
            ))

        await context.close()

    finished_at = datetime.now(timezone.utc)
    duration = (finished_at - started_at).total_seconds()

    auth_failed_tools = [o.tool_name for o in tool_outcomes if o.outcome == ToolOutcome.AUTH_FAILED]
    extraction_failed_tools = [o.tool_name for o in tool_outcomes if o.outcome == ToolOutcome.EXTRACTION_FAILED]
    total_new = sum(len(o.new_versions) for o in tool_outcomes)

    if auth_failed_tools:
        status = "partial_auth_failed"
    elif extraction_failed_tools:
        status = "partial_extraction_failed"
    else:
        status = "success"
    exit_code = 0 if status == "success" else 1

    if auth_failed_tools:
        log_warn(f"세션 만료 의심 도구: {auth_failed_tools}")
    if extraction_failed_tools:
        log_warn(f"추출 실패 도구: {extraction_failed_tools}")
    log(f"변경사항 총 {total_new}건 감지" if total_new else "변경사항 없음")

    result = RunResult(
        started_at=started_at.isoformat(), finished_at=finished_at.isoformat(),
        duration_sec=duration, dry_run=dry_run, tool_outcomes=tool_outcomes,
        status=status, auth_failed_tools=auth_failed_tools,
        extraction_failed_tools=extraction_failed_tools, total_new_versions=total_new,
        exit_code=exit_code,
    )

    if dry_run:
        log("[dry-run] 상태 저장/DB쓰기/이메일 생략")
        _print_summary(result, json_output)
        return result

    # ── DB 쓰기 먼저, 무조건 (Claude 키 유무와 무관) ──────────────────────────
    upsert_rows: list[tuple[str, str, str, str | None, str | None, str | None]] = []
    detected_at = finished_at.isoformat()
    for o in tool_outcomes:
        defn = TOOL_REGISTRY[o.tool_id]
        for android_key, version_str, notes, released_at in o.new_versions:
            upsert_rows.append(
                (defn.suite_name, android_key, version_str, notes, detected_at, released_at),
            )
    db_ok = db.upsert_tool_versions(config, upsert_rows) if upsert_rows else True
    result.db_write_ok = db_ok
    if not db_ok:
        result.db_write_error = "xts_tool_versions upsert 실패 (observer.log 참고)"

    run_id = db.insert_run_result(config, result)

    snapshot.write(display_snapshot)
    log("상태 저장 완료")

    # ── 이메일 (실패해도 위 DB 쓰기는 이미 끝난 상태) ─────────────────────────
    changes_report: list[dict[str, Any]] = []
    for o in tool_outcomes:
        if o.new_versions and o.extraction:
            changes_report.append({
                "name": o.tool_name,
                "changes": diffmod.format_changes(o.new_versions, o.extraction.values),
                "last_updated": o.extraction.last_updated,
            })

    if not config:
        log_warn("config.yaml 없음 — 이메일 미발송")
    else:
        try:
            if test_email:
                log("[test-email] 강제 발송")
                email_mod.send_email(config, changes_report, display_snapshot, targets_all)
            elif auth_failed_tools:
                email_mod.send_email(
                    config, [], display_snapshot, targets_all, auth_failed_tools=auth_failed_tools,
                )
            else:
                email_mod.send_email(config, changes_report, display_snapshot, targets_all)
            result.email_sent = True
        except Exception as e:
            result.email_error = str(e)

    # ── 선택적 Claude 진단 (실패해도 위 어떤 것도 되돌리지 않음) ──────────────
    if do_enrich and run_id:
        log_tail = LOG_FILE.read_text(encoding="utf-8")[-8000:] if LOG_FILE.exists() else ""
        diagnosis = enrich_mod.enrich(result, config, log_tail)
        if diagnosis:
            db.update_run_agent_action(config, run_id, diagnosis)

    log("Tool Observer 완료")
    _print_summary(result, json_output)
    return result


async def run_doctor(target_ids: list[str] | None) -> int:
    """세션/추출만 확인 — DB쓰기·이메일 없음. 문제 생기면 제일 먼저 돌리는 명령.
    실패 시 정확히 뭘 실행해야 하는지까지 출력한다 — "안 된다"고만 하고 끝내지 않음."""
    load_env_files()
    targets_all: list[dict] = load_yaml(TARGETS_FILE)["targets"]
    targets = [t for t in targets_all if not target_ids or t["id"] in target_ids]

    log("=" * 60)
    log(f"Tool Observer doctor — 대상 {len(targets)}개 (DB/이메일 없이 세션+추출만 확인)")

    # (tool_id, status, detail, auth_required)
    results: list[tuple[str, str, str, bool]] = []
    async with async_playwright() as pw:
        context = await browser.launch_context(pw)
        page = await context.new_page()

        auth_targets = [t for t in targets if t.get("auth_required", False)]
        skipped_names = set(await browser.check_session(page, auth_targets))

        for target in targets:
            tid = target["id"]
            auth_req = target.get("auth_required", False)
            defn = TOOL_REGISTRY.get(tid)
            if not defn:
                continue
            if target["name"] in skipped_names:
                results.append((tid, "FAIL", "세션 만료(사전확인에서 로그인 페이지로 리다이렉트됨)", auth_req))
                continue
            try:
                extraction = await defn.extract(page, target)
                outcome = classify.classify_outcome(extraction.values, auth_req)
                if outcome == ToolOutcome.OK:
                    results.append((tid, "OK", "정상", auth_req))
                else:
                    # 사전확인은 통과했지만(로그인 리다이렉트는 없음) 실제 콘텐츠는 못 읽은 경우 —
                    # 현재 페이지 URL을 같이 보여줘야 "로그인 요구 페이지로 슬쩍 넘어갔는지" vs
                    # "그 자리인데 내용만 비었는지" 구분 가능 (후자는 페이지 구조 변경 쪽에 가까움)
                    results.append((tid, "FAIL", f"값 전부 미발견 (현재 URL: {page.url})", auth_req))
            except Exception as e:
                results.append((tid, "FAIL", str(e), auth_req))

        await context.close()

    print("\n==== DOCTOR ====")
    all_ok = True
    failed_auth: list[str] = []
    failed_other: list[str] = []
    for tid, status, detail, auth_req in results:
        if status != "OK":
            all_ok = False
            (failed_auth if auth_req else failed_other).append(tid)
        print(f"{tid:6s} {status:4s}  {detail}")
    print("================")

    if all_ok:
        print("\n모든 도구 정상입니다. 조치 불필요.\n")
        return 0

    print("\n==== 다음 조치 ====")
    if failed_auth:
        print(f"[세션 문제로 추정] 인증 필요 도구 {len(failed_auth)}개 실패: {', '.join(failed_auth)}")
        print(f"  → {SETUP_AUTH_HINT}")
    if failed_other:
        print(f"[세션과 무관한 실패 — 페이지 구조 변경 가능성] 도구 {len(failed_other)}개: {', '.join(failed_other)}")
        print("  → 이 doctor 출력 전체를 그대로 복사해서 Claude에게 붙여넣어 주세요 (해당 tools/<id>.py 수정 필요할 수 있음)")
    print("====================\n")
    return 1


def cmd_status(limit: int, json_output: bool) -> int:
    """DB만 읽음 — 브라우저/네트워크 스크래핑 없음. 빠른 헬스체크용."""
    load_env_files()
    config = _load_config()
    rows = db.fetch_recent_runs(config, limit=1)
    if not rows:
        print("실행 이력이 없습니다.")
        return 1
    row = rows[0]
    if json_output:
        print(json_lib.dumps(row, ensure_ascii=False, default=str))
    else:
        print("\n==== LATEST RUN ====")
        for k, v in row.items():
            print(f"{k}: {v}")
        print("=====================")
        if row["status"] == "auth_failed":
            print(f"\n[조치] 세션 만료 의심 — {SETUP_AUTH_HINT}\n")
        elif row["status"] == "network_error":
            print("\n[조치] PostgreSQL 상태 확인: sudo systemctl status postgresql\n")
        elif row["status"] not in ("success",):
            print("\n[조치] cli.py doctor로 재확인해서 결과를 Claude에게 붙여넣어 주세요.\n")
    return 0 if row["status"] == "success" else 1


def cmd_history(limit: int, json_output: bool) -> int:
    load_env_files()
    config = _load_config()
    rows = db.fetch_recent_runs(config, limit=limit)
    if json_output:
        print(json_lib.dumps(rows, ensure_ascii=False, default=str))
        return 0
    print(f"\n==== RECENT {len(rows)} RUNS ====")
    for row in rows:
        failed = ",".join(row["failed_tools"]) if row["failed_tools"] else "-"
        print(f"{row['run_at']}  {row['status']:24s}  changes={row['changes_count']:<3}  failed=[{failed}]")
    print("=========================")
    return 0


def main():
    parser = argparse.ArgumentParser(description="Tool Observer — XTS 도구 업데이트 감시")
    sub = parser.add_subparsers(dest="command", required=True)

    p_run = sub.add_parser("run", help="스크래핑 + diff + DB 저장 + 이메일")
    p_run.add_argument("--id", nargs="+", metavar="ID", help="실행할 대상 ID (예: --id cts gts)")
    p_run.add_argument("--dry-run", action="store_true", help="변경 감지만, DB쓰기/이메일 없음")
    p_run.add_argument("--test-email", action="store_true", help="전체 버전을 신규로 처리해 강제 발송 (레이아웃 확인용)")
    p_run.add_argument("--enrich", action="store_true", help="선택적 Claude 진단 포함")
    p_run.add_argument("--json", action="store_true", help="마지막에 RunResult를 JSON 한 줄로 출력")

    p_doctor = sub.add_parser("doctor", help="세션/추출만 확인 (DB쓰기·이메일 없음)")
    p_doctor.add_argument("--id", nargs="+", metavar="ID")

    p_status = sub.add_parser("status", help="최근 실행 1건 (DB만 읽음)")
    p_status.add_argument("--json", action="store_true")

    p_history = sub.add_parser("history", help="최근 실행 N건")
    p_history.add_argument("--limit", type=int, default=10)
    p_history.add_argument("--json", action="store_true")

    sub.add_parser("test-email", help="이메일 템플릿 레이아웃 확인용 강제 발송 (run --test-email과 동일)")

    args = parser.parse_args()

    if args.command == "run":
        result = asyncio.run(run_once(
            target_ids=args.id, dry_run=args.dry_run, test_email=args.test_email,
            do_enrich=args.enrich, json_output=args.json,
        ))
        sys.exit(2 if result is None else result.exit_code)

    elif args.command == "test-email":
        result = asyncio.run(run_once(
            target_ids=None, dry_run=False, test_email=True,
            do_enrich=False, json_output=False,
        ))
        sys.exit(2 if result is None else result.exit_code)

    elif args.command == "doctor":
        sys.exit(asyncio.run(run_doctor(args.id)))

    elif args.command == "status":
        sys.exit(cmd_status(limit=1, json_output=args.json))

    elif args.command == "history":
        sys.exit(cmd_history(limit=args.limit, json_output=args.json))


if __name__ == "__main__":
    main()

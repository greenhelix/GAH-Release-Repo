#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""VTS: VTS 탭에서 android_version별 파일명 추출."""

import re
from datetime import datetime, timezone
from typing import Any

from playwright.async_api import Page

from core.log import log
from core.scrape_utils import extract_last_updated, get_page_text
from core.types import ExtractionResult, ToolDefinition

ANDROID_VERSIONS = [
    {"version": "12", "pattern": r"VTS-12_r\d+_arm"},
    {"version": "14", "pattern": r"VTS-14_r\d+_arm"},
    {"version": "16", "pattern": r"VTS-16_r\d+_arm"},
]


async def extract(page: Page, target: dict) -> ExtractionResult:
    await page.goto(target["url"], wait_until="networkidle", timeout=30000)
    text = await get_page_text(page)

    values: dict[str, Any] = {}
    for av in ANDROID_VERSIONS:
        v, pattern = av["version"], av["pattern"]
        # findall로 모두 수집 후 정렬 → 가장 높은 r번호가 최신
        matches = re.findall(pattern, text)
        val = sorted(matches)[-1] if matches else None
        values[v] = val
        log(f"  VTS Android {v}: {val or '미발견'}")

    return ExtractionResult(
        tool_id="vts",
        checked_at=datetime.now(timezone.utc).isoformat(),
        last_updated=extract_last_updated(text),
        values=values,
    )


def normalize_version(av: str, raw_val: Any) -> tuple[str | None, str | None]:
    """VTS-14_r12_arm -> ('R12', None)  android_key는 av ('14')"""
    if not raw_val:
        return None, None
    m = re.match(r"VTS-\d+_r(\d+)_arm", str(raw_val), re.IGNORECASE)
    return (f"R{m.group(1)}", None) if m else (None, None)


DEFINITION = ToolDefinition(
    id="vts", suite_name="VTS", extract=extract, normalize_version=normalize_version,
)

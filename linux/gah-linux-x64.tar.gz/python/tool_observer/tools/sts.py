#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""
STS: 'Get Latest STS Tests' 버튼 클릭 → Google Drive 진입.
Drive 파일 목록에서 Android 14/16 zip 패턴 탐색.
"""

import re
from datetime import datetime, timezone
from typing import Any

from playwright.async_api import Page

from core.log import log, log_warn
from core.scrape_utils import extract_last_updated, get_page_text
from core.types import ExtractionResult, ToolDefinition

ANDROID_VERSIONS = [
    {"version": "14", "pattern": r"android-sts-14_sts-r\d+-linux-arm\w*\.zip"},
    {"version": "16", "pattern": r"android-sts-16_sts-r\d+-linux-arm\w*\.zip"},
]


async def extract(page: Page, target: dict) -> ExtractionResult:
    await page.goto(target["url"], wait_until="load", timeout=60000)
    text_main = await get_page_text(page)
    checked_at = datetime.now(timezone.utc).isoformat()
    last_updated = extract_last_updated(text_main)

    # 메인 페이지 + 모든 프레임에서 버튼 탐색
    target_btn = None
    for frame in page.frames:
        try:
            b = frame.get_by_text("Get Latest STS Tests", exact=False)
            cnt = await b.count()
            if cnt > 0:
                target_btn = b
                break
        except Exception:
            continue

    if target_btn is None:
        log_warn("  STS: 'Get Latest STS Tests' 버튼 미발견")
        return ExtractionResult(
            tool_id="sts", checked_at=checked_at, last_updated=last_updated, values={},
        )

    # href 직접 추출 후 이동 (클릭 대신)
    drive_url = await target_btn.first.evaluate(
        "el => el.tagName === 'A' ? el.href : (el.closest('a') ? el.closest('a').href : null)"
    )

    log("  STS: Google Drive 이동 중...")
    try:
        if drive_url:
            async with page.context.expect_page(timeout=10000) as new_page_info:
                await target_btn.first.click()
            drive_page = await new_page_info.value
        else:
            async with page.context.expect_page(timeout=10000) as new_page_info:
                await target_btn.first.click()
            drive_page = await new_page_info.value
    except Exception:
        drive_page = page

    # Drive UI가 로드될 때까지 대기 (파일 목록 렌더링)
    try:
        await drive_page.wait_for_load_state("networkidle", timeout=30000)
        await drive_page.wait_for_timeout(3000)
    except Exception:
        pass

    drive_text = await drive_page.evaluate("() => document.body.innerText")

    values: dict[str, Any] = {}
    for av in ANDROID_VERSIONS:
        v, pattern = av["version"], av["pattern"]
        match_iter = list(re.finditer(pattern, drive_text))
        if match_iter:
            # r번호 기준 최신 선택 (예: sts-r52 > sts-r50)
            best = max(match_iter, key=lambda m: int(re.search(r"sts-r(\d+)", m.group(0)).group(1)))
            val = best.group(0)
            after = drive_text[best.end():]
            date_modified = None
            for token in [t.strip() for t in after.split("\n")[:10] if t.strip()]:
                if re.match(r"^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}$", token):
                    date_modified = token
                    break
        else:
            val = None
            date_modified = None
        values[v] = {"file": val, "date_modified": date_modified}
        log(f"  STS Android {v}: {val or '미발견'} (날짜: {date_modified or '미발견'})")

    if drive_page is not page:
        await drive_page.close()

    return ExtractionResult(
        tool_id="sts", checked_at=checked_at, last_updated=last_updated, values=values,
    )


def normalize_version(av: str, raw_val: Any) -> tuple[str | None, str | None]:
    """{"file": "android-sts-14_sts-r52-...", "date_modified": "Jun 2"} -> ('R52', 'Jun 2')  android_key는 av"""
    if not isinstance(raw_val, dict):
        return None, None
    file_str = raw_val.get("file") or ""
    date_mod = raw_val.get("date_modified")
    m = re.search(r"android-sts-\d+_sts-r(\d+)", file_str)
    return (f"R{m.group(1)}", date_mod) if m else (None, None)


DEFINITION = ToolDefinition(
    id="sts", suite_name="STS", extract=extract, normalize_version=normalize_version,
)

#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""
도구 등록 — 전체 로스터가 한눈에 보이는 유일한 곳.
새 도구 추가 = tools/<id>.py 파일 하나(extract + normalize_version + DEFINITION)
+ 아래 tuple에 한 줄 추가 + targets.yaml에 한 행(id/name/url/auth_required) 추가.
"""

from core.types import ToolDefinition

from . import cts, gsi, gts, sts, tvts, vts

TOOL_REGISTRY: dict[str, ToolDefinition] = {
    m.DEFINITION.id: m.DEFINITION for m in (cts, tvts, vts, gts, sts, gsi)
}

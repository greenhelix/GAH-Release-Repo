#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""TVTS: 릴리즈 노트 페이지 — 맨 위(가장 먼저 매칭되는) 버전이 최신."""

import re
from datetime import datetime, timezone
from typing import Any

from playwright.async_api import Page

from core.log import log
from core.scrape_utils import extract_last_updated, get_page_text
from core.types import ExtractionResult, ToolDefinition

PATTERNS = [
    {"name": "Latest Version", "pattern": r"TVTS \d+\.\d+ R\d+"},
]

# 각 버전 항목 아코디언 안의 "Release date\nSeptember 24, 2026" 형식.
# innerText는 접힌 아코디언 내용도 DOM에 있으면 그대로 포함하므로, 매칭된
# 버전 문자열 뒤 근처 텍스트를 뒤져서 같은 항목의 릴리즈 날짜를 찾는다.
_RE_RELEASE_DATE = re.compile(r"Release date\s*\n\s*([A-Za-z]+ \d{1,2}, \d{4})")


def _find_release_date(text: str, search_from: int) -> str | None:
    """search_from 이후 가까운 곳(같은 버전 항목 내)에서 릴리즈 날짜를 찾아
    ISO(YYYY-MM-DD) 문자열로 반환한다. 못 찾으면 None."""
    window = text[search_from:search_from + 1500]
    m = _RE_RELEASE_DATE.search(window)
    if not m:
        return None
    try:
        return datetime.strptime(m.group(1), "%B %d, %Y").strftime("%Y-%m-%d")
    except ValueError:
        return None


async def extract(page: Page, target: dict) -> ExtractionResult:
    await page.goto(target["url"], wait_until="networkidle", timeout=30000)
    text = await get_page_text(page)

    values: dict[str, Any] = {}
    release_dates: dict[str, str | None] = {}
    for pat in PATTERNS:
        m = re.search(pat["pattern"], text)
        val = m.group(0) if m else None
        # android_key = TVTS series 버전 (예: "2.18"). 파싱 실패 시 pat["name"] 폴백
        series_m = re.match(r"TVTS\s+(\d+\.\d+)\s+R\d+", val) if val else None
        key = series_m.group(1) if series_m else pat["name"]
        values[key] = val
        release_date = _find_release_date(text, m.end()) if m else None
        release_dates[key] = release_date
        log(f"  TVTS {key}: {val or '미발견'} (릴리즈일: {release_date or '미발견'})")

    return ExtractionResult(
        tool_id="tvts",
        checked_at=datetime.now(timezone.utc).isoformat(),
        last_updated=extract_last_updated(text),
        values=values,
        release_dates=release_dates,
    )


def normalize_version(av: str, raw_val: Any) -> tuple[str | None, str | None]:
    """TVTS 2.18 R1 -> android_key='2.18', version='R1'
    TVTS는 android_key = series 버전 (2.18, 2.19 등)"""
    if not raw_val:
        return None, None
    m = re.match(r"TVTS\s+(\d+\.\d+)\s+R(\d+)", str(raw_val))
    return (f"R{m.group(2)}", None) if m else (None, None)




DEFINITION = ToolDefinition(
    id="tvts", suite_name="TVTS", extract=extract, normalize_version=normalize_version,
)

#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""CTS: source.android.com — 로그인 불필요 공개 페이지."""

import re
from datetime import datetime, timezone
from typing import Any

from playwright.async_api import Page

from core.log import log
from core.scrape_utils import extract_last_updated, get_page_text
from core.types import ExtractionResult, ToolDefinition

ANDROID_VERSIONS = [
    {"version": "12", "pattern": r"android-cts-12\.0_r\d+"},
    {"version": "14", "pattern": r"android-cts-14\.0_r\d+"},
    {"version": "16", "pattern": r"android-cts-16\.0_r\d+"},
]


async def extract(page: Page, target: dict) -> ExtractionResult:
    await page.goto(target["url"], wait_until="networkidle", timeout=30000)
    text = await get_page_text(page)

    values: dict[str, Any] = {}
    for av in ANDROID_VERSIONS:
        v, pattern = av["version"], av["pattern"]
        m = re.search(pattern, text)
        val = m.group(0) if m else None
        values[v] = val
        log(f"  CTS Android {v}: {val or '미발견'}")

    return ExtractionResult(
        tool_id="cts",
        checked_at=datetime.now(timezone.utc).isoformat(),
        last_updated=extract_last_updated(text),
        values=values,
    )


def normalize_version(av: str, raw_val: Any) -> tuple[str | None, str | None]:
    """android-cts-14.0_r12 -> ('R12', None)  android_key는 av ('14')"""
    if not raw_val:
        return None, None
    m = re.match(r"android-cts-\d+\.\d+_r(\d+)", str(raw_val))
    return (f"R{m.group(1)}", None) if m else (None, None)


DEFINITION = ToolDefinition(
    id="cts", suite_name="CTS", extract=extract, normalize_version=normalize_version,
)

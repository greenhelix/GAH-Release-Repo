#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""GTS: 테이블 파싱 — Target Platform 범위 기반으로 Android 버전별 File 추출."""

import re
from datetime import datetime, timezone
from typing import Any

from playwright.async_api import Page

from core.log import log
from core.scrape_utils import extract_last_updated, get_page_text, platform_includes
from core.types import ExtractionResult, ToolDefinition

ANDROID_VERSIONS = ["12", "14", "16"]


async def extract(page: Page, target: dict) -> ExtractionResult:
    await page.goto(target["url"], wait_until="load", timeout=60000)

    # DOM에서 테이블 행 추출 (셀 텍스트 배열)
    rows: list[list[str]] = await page.evaluate("""
        () => {
            const result = [];
            document.querySelectorAll('table tr').forEach(tr => {
                const cells = Array.from(tr.querySelectorAll('td, th'))
                                   .map(td => td.innerText.trim());
                if (cells.length >= 2) result.push(cells);
            });
            return result;
        }
    """)

    text = await get_page_text(page)
    log(f"  GTS 테이블 행 {len(rows)}개 발견")

    values: dict[str, Any] = {}
    for v in ANDROID_VERSIONS:
        ver_int = int(v)
        best_file = None
        best_series = -1

        for row in rows:
            # 테이블 컬럼 추정: [Series, Platform, File] or [Platform, File] 등
            for cell in row:
                # GTS_13.1_r2 형식과 GTS_12_r3 (minor 없음) 형식 모두 지원
                gts_m = re.search(r"GTS_(\d+)(?:\.(\d+))?_r\d+", cell)
                if not gts_m:
                    continue
                minor = int(gts_m.group(2)) if gts_m.group(2) else 0
                series_num = int(gts_m.group(1)) * 100 + minor

                row_text = " | ".join(row)
                if platform_includes(row_text, ver_int):
                    if series_num > best_series:
                        best_series = series_num
                        best_file = re.search(r"GTS_\d+(?:\.\d+)?_r\d+", cell).group(0)

        values[v] = best_file
        log(f"  GTS Android {v}: {best_file or '미발견'}")

    return ExtractionResult(
        tool_id="gts",
        checked_at=datetime.now(timezone.utc).isoformat(),
        last_updated=extract_last_updated(text),
        values=values,
    )


def normalize_version(av: str, raw_val: Any) -> tuple[str | None, str | None]:
    """GTS_13.1_r2 또는 GTS_14_r1 -> ('R2', None)  android_key는 av ('14')"""
    if not raw_val:
        return None, None
    m = re.match(r"GTS_(?:\d+)(?:\.\d+)?_r(\d+)", str(raw_val))
    return (f"R{m.group(1)}", None) if m else (None, None)


DEFINITION = ToolDefinition(
    id="gts", suite_name="GTS", extract=extract, normalize_version=normalize_version,
)

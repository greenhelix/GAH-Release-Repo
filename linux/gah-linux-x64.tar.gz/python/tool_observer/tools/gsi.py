#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""
GSI: 전체 페이지에서 Build 위치 기반으로 Android 버전 귀속.
페이지 상단 네비게이션과 본문이 분리되어 있어 섹션 파싱 대신 사용.
"""

import re
from datetime import datetime, timezone
from typing import Any

from playwright.async_api import Page

from core.log import log, log_warn
from core.scrape_utils import extract_last_updated, get_page_text
from core.types import ExtractionResult, ToolDefinition

ANDROID_VERSIONS = ["12", "14", "16"]


async def extract(page: Page, target: dict) -> ExtractionResult:
    await page.goto(target["url"], wait_until="load", timeout=60000)

    try:
        await page.wait_for_function(
            "() => document.body.innerText.includes('released on')",
            timeout=15000,
        )
    except Exception:
        log_warn("  GSI: 콘텐츠 로딩 대기 타임아웃")

    text = await get_page_text(page)

    # 각 Build 패턴의 위치와 직전 Android 버전 번호를 매핑
    # "Android X" 직후 처음 등장하는 Build가 해당 버전의 최신 빌드
    target_versions = set(ANDROID_VERSIONS)
    version_build: dict[str, str | None] = {}
    version_patch: dict[str, str | None] = {}

    for m in re.finditer(r"Build\s+\d+\s*\(released on [^)]+\)", text):
        before = text[:m.start()]
        android_m = re.findall(r"Android\s+(\d+)", before)
        if not android_m:
            continue
        ver = android_m[-1]
        if ver in target_versions and ver not in version_build:
            version_build[ver] = m.group(0)

    for m in re.finditer(r"Security patch level is updated to\s+([\d-]+)", text):
        before = text[:m.start()]
        android_m = re.findall(r"Android\s+(\d+)", before)
        if not android_m:
            continue
        ver = android_m[-1]
        if ver in target_versions and ver not in version_patch:
            version_patch[ver] = m.group(1)

    values: dict[str, Any] = {}
    for v in ANDROID_VERSIONS:
        ver_data = {
            "build": version_build.get(v),
            "security_patch": version_patch.get(v),
        }
        values[v] = ver_data
        log(f"  GSI Android {v}: {ver_data}")

    return ExtractionResult(
        tool_id="gsi",
        checked_at=datetime.now(timezone.utc).isoformat(),
        last_updated=extract_last_updated(text),
        values=values,
    )


def normalize_version(av: str, raw_val: Any) -> tuple[str | None, str | None]:
    """{"build": "Build 15343429 (released on ...)", "security_patch": "..."} -> ('15343429', spl)
    GSI android_key는 항상 'ALL'. spl(security patch level)은 notes에 저장"""
    if not isinstance(raw_val, dict):
        return None, None
    build = raw_val.get("build") or ""
    spl = raw_val.get("security_patch")
    m = re.search(r"Build\s+(\d+)", build)
    return (m.group(1), spl or None) if m else (None, None)


DEFINITION = ToolDefinition(
    id="gsi", suite_name="GSI", extract=extract, normalize_version=normalize_version,
)

# Tool Observer — 설치 및 운영 가이드

## 파일 구조

```
tool_observer/
├── tool_observer.py     # 메인 감시 스크립트
├── setup_auth.py        # 세션 설정 (GUI 로그인)
├── install.sh           # 신규 서버 환경 세팅 자동화
├── run.sh               # cron 실행 래퍼
├── targets.yaml         # 감시 대상 설정
├── config.yaml          # 이메일 설정 (gitignore)
├── credentials.json     # Gmail API OAuth2 클라이언트 (gitignore)
├── state.json           # 이전 상태 저장 (자동 생성)
├── observer.log         # 실행 로그 (자동 생성)
└── auth/
    ├── browser_profile/ # Playwright 영구 프로필 (gitignore)
    └── gmail_token.json # Gmail API 토큰 (자동 생성)
```

---

## 신규 서버 최초 세팅

### 1단계 — 코드 준비

```bash
# 방법 A: GAH repo 전체 clone
git clone <repo-url>
cd python/tool_observer

# 방법 B: tool_observer 폴더만 복사
scp -r tool_observer/ user@server:~/tool_observer
cd ~/tool_observer
```

### 2단계 — 환경 세팅 (자동)

```bash
bash install.sh
```

내부 동작:
- Python venv 생성 (`venv/`)
- pip 의존성 설치
- Playwright Chromium 바이너리 설치
- 시스템 의존성 설치 (libglib, libnss 등)

### 3단계 — 설정 파일 배치

```bash
# config.yaml 생성 (이메일 발신/수신 설정)
cp config.yaml.example config.yaml
vi config.yaml

# credentials.json 배치 (Google Cloud Console OAuth2 클라이언트)
# → 기존 서버에서 복사하거나 Google Cloud Console에서 새로 발급
scp user@oldserver:~/tool_observer/credentials.json .
```

### 4단계 — 구글 파트너 포털 로그인 (세션 생성)

```bash
source venv/bin/activate
python setup_auth.py
# GUI 브라우저 창 열림 → 로그인 → Enter
```

> GUI 없는 서버: SSH X-forwarding 사용
> ```bash
> ssh -X user@server
> python setup_auth.py
> ```

### 5단계 — Gmail API 인증

```bash
python tool_observer.py --test-email
# 브라우저 OAuth2 인증 팝업 → 완료
# auth/gmail_token.json 자동 생성됨
```

### 6단계 — cron 등록

```bash
crontab -e
```

추가:
```
0 9 * * * cd ~/tool_observer && venv/bin/python tool_observer.py >> observer.log 2>&1
```

---

## 오류 상황별 대처

### Python 버전 오류 (3.8 등 구버전)

증상: `install.sh` 실행 시 "Python 3.10 이상을 찾을 수 없습니다"

```bash
# Ubuntu 20.04/22.04
sudo apt update
sudo apt install -y python3.10 python3.10-venv

# 설치 확인
python3.10 --version

# 다시 실행
bash install.sh
```

> venv가 이미 생성된 경우 삭제 후 재실행
> ```bash
> rm -rf venv && bash install.sh
> ```

---

### pip install 오류 — `No module named 'yaml'`

원인: `pip install yaml` (잘못된 패키지명) 또는 venv 바깥의 pip로 설치

```bash
# 반드시 venv 안의 pip 사용
venv/bin/pip install -r requirements.txt
```

---

### Playwright 관련 오류

**`ModuleNotFoundError: No module named 'playwright'`**
```bash
source venv/bin/activate
pip install playwright
```

**`Executable doesn't exist` / `BrowserType.launch failed`**
```bash
source venv/bin/activate
playwright install chromium
```

**`libglib2.0` / `libnss3` 등 시스템 라이브러리 오류**
```bash
source venv/bin/activate
playwright install-deps chromium
```

**전체 재설치 (위 방법 모두 실패 시)**
```bash
bash install.sh
```

---

### 세션 만료 (파트너 포털 접근 불가)

증상: `observer.log`에 "세션 만료" 또는 로그인 페이지 감지

```bash
cd ~/tool_observer
source venv/bin/activate
python setup_auth.py
# GUI 창에서 로그인 → Enter
```

---

### Gmail 토큰 만료 (이메일 발송 실패)

증상: `observer.log`에 Gmail API 인증 오류

```bash
rm auth/gmail_token.json
source venv/bin/activate
python tool_observer.py --test-email
# 브라우저 OAuth2 인증 팝업 → 완료
```

---

### SingletonLock 오류 (다른 머신에서 복사 후)

증상: `browser_profile already in use`

```bash
rm auth/browser_profile/SingletonLock
```

> `setup_auth.py`와 `tool_observer.py` 실행 시 자동으로 제거됨.

---

## 테스트 명령어

```bash
source venv/bin/activate

# 크롤링만 (이메일/상태 저장 없음)
python tool_observer.py --dry-run

# 전체 실행 + 강제 이메일 발송
python tool_observer.py --test-email
```

---

## 수신자 추가

`config.yaml` 수정:

```yaml
smtp:
  from: yourmail@gmail.com
  to:
    - recipient1@example.com
    - recipient2@example.com
```

#!/usr/bin/env python3
"""
세션 설정 도구 — Ubuntu 서버에서 Playwright Chromium GUI로 직접 로그인.

최초 1회 또는 세션 만료 시 실행한다.
로그인 후 browser_profile에 영구 저장 → cli.py가 headless로 재사용.

사용법:
  python setup_auth.py
"""

import asyncio
import subprocess
import sys
from pathlib import Path

from playwright.async_api import async_playwright

PROFILE_DIR = Path(__file__).parent / "auth" / "browser_profile"
TARGET_URL = "https://docs.partner.android.com/gms/testing/gts?hl=en"


def remove_singleton_lock():
    """이전 실행의 잔여 락 파일 제거 (비정상 종료 또는 다른 머신에서 복사 시 발생)"""
    lock = PROFILE_DIR / "SingletonLock"
    if lock.exists() or lock.is_symlink():
        lock.unlink()
        print(f"  SingletonLock 제거 완료")


async def main():
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    remove_singleton_lock()

    print("=" * 60)
    print("Tool Observer — 구글 파트너 포털 세션 설정")
    print("=" * 60)
    print()
    print(f"브라우저 프로필: {PROFILE_DIR}")
    print()

    async with async_playwright() as pw:
        context = await pw.chromium.launch_persistent_context(
            str(PROFILE_DIR),
            headless=False,
            args=[
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-blink-features=AutomationControlled",
            ],
            ignore_default_args=["--enable-automation"],
        )

        page = await context.new_page()
        await page.goto(TARGET_URL)

        print("[ 진행 순서 ]")
        print("  1. 브라우저 창에서 Google 계정으로 로그인")
        print(f"     {TARGET_URL}")
        print("  2. 파트너 포털 페이지가 정상 표시되면 이 터미널에서 Enter")
        print()
        input(">>> 로그인 및 포털 접근 확인 후 Enter: ")

        await context.close()

    print()
    print(f"세션 저장 완료: {PROFILE_DIR}")
    print()
    print("버전 수집 및 메일 발송을 시작합니다...")
    print()
    # cli.py run이 자체적으로 .env.agent를 로드하므로(core/dotenv.py), 이 스크립트를
    # 터미널에서 직접 실행하든 systemd가 실행하든 항상 동일하게 동작한다.
    # (구: agent_runner.py는 .env.agent 자동 로드가 없어 수동 실행 시 크래시했음)
    subprocess.run([sys.executable, str(Path(__file__).parent / "cli.py"), "run", "--enrich"])


if __name__ == "__main__":
    asyncio.run(main())

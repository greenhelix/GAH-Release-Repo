#!/usr/bin/env python3
"""
Windows Chrome의 로그인 세션을 추출해 auth.json으로 저장.

사용법:
  python extract_session.py          # 대화형 (수동 실행)
  python extract_session.py --auto   # 자동 모드 (cron용, Chrome 실행 중일 때만 성공)

--auto 모드:
  - Chrome이 실행 중이고 Google 쿠키가 있으면 조용히 갱신 후 exit 0
  - Chrome이 없거나 쿠키 없으면 메시지 없이 exit 1
"""

import argparse
import asyncio
import json
import sys
import urllib.request
from pathlib import Path

AUTH_DIR = Path(__file__).parent / "auth"
AUTH_FILE = AUTH_DIR / "auth.json"

VERIFY_URLS = [
    ("docs.partner.android.com", "https://docs.partner.android.com/gms/testing/gts?hl=en"),
    ("source.android.com", "https://source.android.com/docs/compatibility/cts/downloads"),
]


def get_windows_host() -> str:
    import subprocess
    try:
        result = subprocess.run(
            ["ip", "route", "show", "default"],
            capture_output=True, text=True
        )
        parts = result.stdout.split()
        via_idx = parts.index("via") if "via" in parts else -1
        if via_idx >= 0:
            return parts[via_idx + 1]
    except Exception:
        pass
    return "localhost"


def try_connect(debug_url: str) -> dict | None:
    """Chrome 디버깅 포트 연결 시도. 실패 시 None 반환."""
    try:
        req = urllib.request.urlopen(f"{debug_url}/json/version", timeout=3)
        return json.loads(req.read())
    except Exception:
        return None


async def extract_cookies(debug_url: str) -> dict | None:
    """Chrome에서 storage_state 추출. 실패 시 None 반환."""
    from playwright.async_api import async_playwright
    try:
        async with async_playwright() as pw:
            browser = await pw.chromium.connect_over_cdp(debug_url)
            contexts = browser.contexts
            if not contexts:
                await browser.close()
                return None
            storage = await contexts[0].storage_state()
            await browser.close()
            return storage
    except Exception:
        return None


async def run(auto: bool):
    AUTH_DIR.mkdir(exist_ok=True)

    host = get_windows_host()
    debug_url = f"http://{host}:9222"

    if not auto:
        print("=" * 60)
        print("Tool Observer — Windows Chrome 세션 추출")
        print("=" * 60)
        print(f"\n연결 대상: {debug_url}\n")

    # Chrome 연결 확인
    version_info = try_connect(debug_url)
    if not version_info:
        if not auto:
            print(f"❌ Chrome에 연결할 수 없습니다.")
            print("\nWindows에서 아래 명령으로 Chrome을 실행하세요:")
            print('  chrome.exe --remote-debugging-port=9222 --user-data-dir=C:\\Temp\\chrome-debug')
        sys.exit(1)

    if not auto:
        print(f"✅ Chrome 연결 성공: {version_info.get('Browser', 'unknown')}")
        print("\n브라우저에서 아래 사이트들이 정상 로드되는지 확인하세요:")
        for name, url in VERIFY_URLS:
            print(f"  - {name}\n    {url}")
        input("\n>>> 확인 완료 후 Enter: ")

    # 쿠키 추출
    if not auto:
        print("세션 추출 중...")
    storage = await extract_cookies(debug_url)
    if not storage:
        if not auto:
            print("❌ 세션 추출 실패")
        sys.exit(1)

    cookies = storage.get("cookies", [])
    google_cookies = [
        c for c in cookies
        if "google" in c.get("domain", "") or "android.com" in c.get("domain", "")
    ]

    if not google_cookies:
        if not auto:
            print("⚠️  구글 관련 쿠키 없음 — Chrome에서 로그인 후 다시 시도하세요.")
        sys.exit(1)

    with open(AUTH_FILE, "w", encoding="utf-8") as f:
        json.dump(storage, f, ensure_ascii=False, indent=2)

    if auto:
        print(f"[extract_session] 세션 갱신 완료 ({len(google_cookies)}개 쿠키)")
    else:
        print(f"\n✅ 세션 저장 완료: {AUTH_FILE}")
        print(f"   구글 관련 쿠키: {len(google_cookies)}개")
        print("\n이제 tool_observer.py를 실행할 수 있습니다.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--auto", action="store_true",
                        help="자동 모드 (cron용): 사용자 입력 없이 실행, 실패 시 exit 1")
    args = parser.parse_args()
    asyncio.run(run(auto=args.auto))

#!/usr/bin/env python3
# Python 3.8 호환: list[str], tuple[int, float] 등 런타임 평가 없이 문자열로 처리
from __future__ import annotations

"""
Tool Observer AI Agent Runner (Phase 1+2+3)

tool_observer.py를 subprocess로 실행 후 Claude API로 결과를 분석하고,
- 세션 만료 → rsync 안내 이메일 발송
- URL 변경 의심 → targets.yaml 자동 수정 후 재실행
- 실행 결과 → PostgreSQL tool_observer_runs 테이블에 저장

실행 방법:
  python agent_runner.py              # 정상 실행
  python agent_runner.py --dry-run    # 이메일/DB 저장 없이 분석만

환경 변수:
  ANTHROPIC_API_KEY   Claude API 키 (필수)
  DB_HOST             PostgreSQL 호스트 (기본: localhost)
  DB_PORT             PostgreSQL 포트 (기본: 5432)
  DB_NAME             DB 이름 (기본: gah)
  DB_USER             DB 사용자 (기본: gah_user)
  DB_PASSWORD         DB 비밀번호
"""

import argparse
import base64
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

import anthropic
import psycopg2
import yaml
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

BASE_DIR = Path(__file__).parent
TARGETS_FILE = BASE_DIR / "targets.yaml"
LOG_FILE = BASE_DIR / "observer.log"
STATE_FILE = BASE_DIR / "state.json"
CONFIG_FILE = BASE_DIR / "config.yaml"
GMAIL_TOKEN = BASE_DIR / "auth" / "gmail_token.json"
GMAIL_CREDENTIALS = BASE_DIR / "credentials.json"
GMAIL_SCOPES = ["https://www.googleapis.com/auth/gmail.send"]

SUITE_NAME_MAP = {
    "cts": "CTS",
    "vts": "VTS",
    "gts": "GTS",
    "sts": "STS",
    "tvts": "TVTS",
    "gsi": "GSI",
}

MODEL = "claude-haiku-4-5-20251001"
MAX_LOG_CHARS = 10000  # 최근 로그 상한 (토큰 절약)

SETUP_AUTH_CMD = "cd ~/xts/gah_code/python/tool_observer && python3 setup_auth.py"


# ── 로그 ──────────────────────────────────────────────────────────────────────

def log(msg: str, level: str = "INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] [AGENT/{level}] {msg}", flush=True)


def notify_desktop(title: str, message: str, urgency: str = "critical"):
    """Gmail 알림 자체가 실패했을 때의 최후 수단 — Google 인증에 의존하지 않는
    로컬 데스크톱 알림. 이메일 발송 실패는 이 경로로만 사람에게 닿는다."""
    uid = os.getuid()
    env = os.environ.copy()
    env.setdefault("DISPLAY", ":0")
    env.setdefault("XAUTHORITY", f"/run/user/{uid}/gdm/Xauthority")
    env.setdefault("DBUS_SESSION_BUS_ADDRESS", f"unix:path=/run/user/{uid}/bus")
    try:
        subprocess.run(
            ["notify-send", "-u", urgency, "--expire-time=0", title, message],
            env=env, timeout=10, check=False,
        )
    except Exception as e:
        log(f"데스크톱 알림도 실패: {e}", "ERROR")


# ── Gmail 발송 ─────────────────────────────────────────────────────────────────

def _get_gmail_service():
    creds = None
    if GMAIL_TOKEN.exists():
        creds = Credentials.from_authorized_user_file(str(GMAIL_TOKEN), GMAIL_SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            raise RuntimeError(
                "Gmail 토큰 만료 또는 미존재. Mac에서 setup_auth.py를 실행한 후 rsync 하세요."
            )
        GMAIL_TOKEN.write_text(creds.to_json())
    return build("gmail", "v1", credentials=creds)


def _send_gmail(config: dict, subject: str, html: str, alert_only: bool = False):
    smtp = config.get("smtp", {})
    recipients = smtp.get("alert_to") or smtp.get("to", [])
    if not recipients:
        log("이메일 수신자 미설정 (config.yaml 확인)", "WARN")
        return

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = smtp.get("from", "")
    msg["To"] = ", ".join(recipients)
    msg.attach(MIMEText(html, "html", "utf-8"))

    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    try:
        service = _get_gmail_service()
        service.users().messages().send(userId="me", body={"raw": raw}).execute()
        log(f"이메일 발송 완료 → {recipients}")
    except Exception as e:
        log(f"이메일 발송 실패 — Gmail 인증 문제로 추정: {e}", "ERROR")
        notify_desktop(
            "⚠️ Tool Observer 이메일 발송 실패",
            "Gmail 인증 오류로 알림 메일을 못 보냈습니다. 터미널에서 재인증하세요:\n"
            "cd ~/xts/gah_code/python/tool_observer\n"
            "rm auth/gmail_token.json && ./venv/bin/python tool_observer.py --test-email\n"
            f"오류: {e}",
        )
        raise


# ── Tool 구현 ─────────────────────────────────────────────────────────────────

def tool_read_log() -> str:
    """observer.log 읽기 (최근 MAX_LOG_CHARS 글자)"""
    if not LOG_FILE.exists():
        return "(observer.log 없음 — tool_observer.py가 아직 실행되지 않았거나 실패했습니다)"
    text = LOG_FILE.read_text(encoding="utf-8")
    if len(text) > MAX_LOG_CHARS:
        return f"...(앞부분 생략, 총 {len(text)}자)...\n" + text[-MAX_LOG_CHARS:]
    return text


def tool_read_targets() -> str:
    """targets.yaml 읽기"""
    if not TARGETS_FILE.exists():
        return "(targets.yaml 없음)"
    return TARGETS_FILE.read_text(encoding="utf-8")


def tool_update_target_url(target_id: str, new_url: str) -> str:
    """targets.yaml의 특정 대상 URL 수정"""
    data = yaml.safe_load(TARGETS_FILE.read_text(encoding="utf-8"))
    for target in data.get("targets", []):
        if target["id"] == target_id:
            old_url = target.get("url", "")
            target["url"] = new_url
            with open(TARGETS_FILE, "w", encoding="utf-8") as f:
                yaml.dump(data, f, allow_unicode=True, default_flow_style=False, sort_keys=False)
            log(f"targets.yaml 수정 완료: [{target_id}] {old_url} → {new_url}")
            return f"수정 완료: [{target_id}] url = {new_url}"
    return f"오류: target_id '{target_id}' 미발견"


def tool_send_rsync_alert(failed_tools: list[str], config: dict, dry_run: bool) -> str:
    """세션 만료 + rsync 안내 이메일 발송"""
    if dry_run:
        log(f"[dry-run] rsync 안내 알림 생략 — 실패 도구: {failed_tools}")
        return f"[dry-run] 알림 생략. 실패 도구: {failed_tools}"
    if not config:
        log("config.yaml 없음 — rsync 안내 알림 미발송", "WARN")
        return "config.yaml 없음 — 알림 미발송"

    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    tool_list = "".join(f"<li><code>{t}</code></li>" for t in failed_tools)
    html = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0;background:#f5f5f5">
  <div style="max-width:680px;margin:24px auto;padding:0 16px">
    <div style="background:#B71C1C;border-radius:10px 10px 0 0;padding:20px 24px">
      <div style="color:#fff;font-size:20px;font-weight:bold">⚠️ 구글 세션 만료 — 재인증 필요</div>
      <div style="color:#EF9A9A;font-size:13px;margin-top:4px">감지 일시: {today}</div>
    </div>
    <div style="background:#fff;border-radius:0 0 8px 8px;border:1px solid #e0e0e0;padding:20px 24px">
      <p style="color:#333;font-size:14px">아래 도구의 Google 로그인 세션이 만료되었습니다:</p>
      <ul style="color:#B71C1C;font-size:14px">{tool_list}</ul>
      <hr style="border:none;border-top:1px solid #eee;margin:16px 0">
      <p style="color:#333;font-size:14px;font-weight:bold">✅ 해결 방법 — DB PC에서 아래 명령어를 실행하세요:</p>
      <div style="background:#1e1e1e;border-radius:6px;padding:14px;margin:8px 0">
        <code style="color:#d4d4d4;font-size:13px">{SETUP_AUTH_CMD}</code>
      </div>
      <p style="font-size:12px;color:#777;margin-top:8px">브라우저 창이 열리면 Google 계정으로 로그인 후 터미널에서 Enter를 누르세요.</p>
    </div>
    <div style="text-align:center;padding:16px;color:#aaa;font-size:11px">GAH Tool Observer Agent — 자동 발송 메일입니다.</div>
  </div>
</body>
</html>"""

    try:
        _send_gmail(config, f"[GAH] ⚠️ 세션 만료 — 재인증 필요 ({today[:10]})", html, alert_only=True)
        return f"rsync 안내 알림 발송 완료 → {failed_tools}"
    except Exception as e:
        log(f"알림 발송 실패: {e}", "WARN")
        return f"알림 발송 실패: {e}"


def tool_save_run_result(
    status: str,
    changes_count: int,
    failed_tools: list[str],
    error_summary: str,
    agent_action: str,
    exit_code: int,
    duration_sec: float,
    dry_run: bool,
) -> str:
    """실행 결과를 tool_observer_runs 테이블에 저장"""
    if dry_run:
        summary = {
            "status": status,
            "changes_count": changes_count,
            "failed_tools": failed_tools,
            "error_summary": error_summary,
            "agent_action": agent_action,
        }
        log(f"[dry-run] DB 저장 생략: {json.dumps(summary, ensure_ascii=False)}")
        return f"[dry-run] DB 저장 생략: status={status}, changes={changes_count}"

    try:
        conn = psycopg2.connect(
            host=os.environ.get("DB_HOST", "localhost"),
            port=int(os.environ.get("DB_PORT", "5432")),
            dbname=os.environ.get("DB_NAME", "gah"),
            user=os.environ.get("DB_USER", "gah_user"),
            password=os.environ.get("DB_PASSWORD", ""),
        )
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO tool_observer_runs
                (status, changes_count, failed_tools, error_summary,
                 agent_action, observer_exit_code, run_duration_sec)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (
                status,
                changes_count,
                failed_tools if failed_tools else [],
                error_summary or "",
                agent_action or "",
                exit_code,
                round(duration_sec, 2),
            ),
        )
        conn.commit()
        cur.close()
        conn.close()
        log("실행 결과 DB 저장 완료")
        return f"DB 저장 완료: status={status}, changes={changes_count}"
    except Exception as e:
        log(f"DB 저장 실패: {e}", "WARN")
        return f"DB 저장 실패: {e}"


# ── 감지 버전 → xts_tool_versions 저장 ──────────────────────────────────────

def _parse_version_entry(tool_id: str, raw_val) -> tuple[str | None, str | None]:
    """state.json 버전 값을 (version_str, notes)로 파싱"""
    import re
    if raw_val is None:
        return None, None

    if isinstance(raw_val, dict):
        # STS: {"file": "android-sts-14_sts-r52-...", "date_modified": "Jun 2"}
        if "file" in raw_val:
            file_str = raw_val.get("file") or ""
            date_mod = raw_val.get("date_modified")
            m = re.search(r"android-sts-(\d+)_sts-r(\d+)", file_str)
            if m:
                return f"{m.group(1)}_sts-r{m.group(2)}", date_mod
            return None, None
        # GSI: {"build": "Build XXXXXXX (released on ...)", "security_patch": "..."}
        if "build" in raw_val:
            build = raw_val.get("build") or ""
            spl = raw_val.get("security_patch")
            m = re.search(r"Build\s+(\d+)", build)
            if m:
                return f"build{m.group(1)}", spl or None
            return None, None
        return None, None

    raw = str(raw_val)
    # CTS: android-cts-14.0_r12
    m = re.match(r"android-cts-(\d+\.\d+)_r(\d+)", raw)
    if m:
        return f"{m.group(1)}_r{m.group(2)}", None
    # VTS: VTS-14_r12_arm
    m = re.match(r"VTS-(\d+)_r(\d+)_arm", raw, re.IGNORECASE)
    if m:
        return f"{m.group(1)}_r{m.group(2)}", None
    # GTS: GTS_13.1_r2 or GTS_14_r1
    m = re.match(r"GTS_(\d+)(?:\.(\d+))?_r(\d+)", raw)
    if m:
        series = m.group(1) + (f".{m.group(2)}" if m.group(2) else "")
        return f"{series}_r{m.group(3)}", None
    # TVTS: TVTS 2.18 R1
    m = re.match(r"TVTS\s+(\d+\.\d+)\s+R(\d+)", raw)
    if m:
        return f"{m.group(1)}_r{m.group(2)}", None
    return raw, None


def save_detected_versions_to_db(dry_run: bool) -> int:
    """state.json 감지 버전 → xts_tool_versions 테이블 upsert"""
    if not STATE_FILE.exists():
        log("state.json 없음 — 버전 DB 저장 건너뜀", "WARN")
        return 0

    try:
        state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception as e:
        log(f"state.json 파싱 실패: {e}", "WARN")
        return 0

    rows: list[tuple] = []
    for tool_id, tool_data in state.items():
        suite_name = SUITE_NAME_MAP.get(tool_id)
        if not suite_name:
            continue
        for android_ver, raw_val in tool_data.get("versions", {}).items():
            version_str, notes = _parse_version_entry(tool_id, raw_val)
            if version_str:
                rows.append((suite_name, version_str, notes))

    if not rows:
        log("저장할 버전 데이터 없음")
        return 0

    if dry_run:
        for suite_name, version_str, notes in rows:
            log(f"[dry-run] xts_tool_versions: {suite_name} {version_str} (notes={notes})")
        return len(rows)

    try:
        conn = psycopg2.connect(
            host=os.environ.get("DB_HOST", "localhost"),
            port=int(os.environ.get("DB_PORT", "5432")),
            dbname=os.environ.get("DB_NAME", "gah"),
            user=os.environ.get("DB_USER", "gah_user"),
            password=os.environ.get("DB_PASSWORD", ""),
        )
        cur = conn.cursor()
        for suite_name, version_str, notes in rows:
            cur.execute(
                """
                INSERT INTO xts_tool_versions (suite_name, version, notes)
                VALUES (%s, %s, %s)
                ON CONFLICT (suite_name, version)
                DO UPDATE SET notes = COALESCE(EXCLUDED.notes, xts_tool_versions.notes)
                """,
                (suite_name, version_str, notes),
            )
        conn.commit()
        cur.close()
        conn.close()
        log(f"xts_tool_versions 저장 완료: {len(rows)}건")
        return len(rows)
    except Exception as e:
        log(f"xts_tool_versions 저장 실패: {e}", "WARN")
        return 0


# ── Claude 에이전트 도구 정의 ──────────────────────────────────────────────────

TOOLS = [
    {
        "name": "read_log",
        "description": (
            "observer.log 파일을 읽어 tool_observer.py 실행 결과를 확인한다. "
            "세션 만료, URL 미발견, 네트워크 오류 등의 단서를 파악할 때 사용한다."
        ),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "read_targets",
        "description": (
            "targets.yaml 파일을 읽어 현재 감시 대상의 URL과 패턴을 확인한다. "
            "URL 변경이 의심될 때 현재 설정값을 파악하는 데 사용한다."
        ),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "update_target_url",
        "description": (
            "targets.yaml에서 특정 대상의 URL을 수정한다. "
            "로그에서 새 URL을 명확히 확인했을 때만 사용한다. "
            "새 URL이 불확실하면 사용하지 않는다."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "target_id": {
                    "type": "string",
                    "description": "수정할 대상의 ID (예: cts, gts, vts, tvts, sts, gsi)",
                },
                "new_url": {
                    "type": "string",
                    "description": "새로운 URL (리다이렉트 URL 또는 로그에서 확인된 URL)",
                },
            },
            "required": ["target_id", "new_url"],
        },
    },
    {
        "name": "send_rsync_alert",
        "description": (
            "구글 세션 만료 알림 + rsync 복구 방법을 이메일로 발송한다. "
            "세션 만료(auth_failed)가 확실할 때 사용한다."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "failed_tools": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "세션 만료로 실패한 도구 이름 목록 (예: ['GTS Tool', 'VTS Tool'])",
                },
            },
            "required": ["failed_tools"],
        },
    },
    {
        "name": "save_run_result",
        "description": (
            "이번 실행 결과를 PostgreSQL tool_observer_runs 테이블에 저장한다. "
            "분석이 끝난 후 반드시 마지막에 호출해야 한다."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "enum": ["success", "auth_failed", "url_changed", "network_error", "unknown_error"],
                    "description": "실행 결과 상태",
                },
                "changes_count": {
                    "type": "integer",
                    "description": "감지된 버전 변경사항 수 (없으면 0)",
                },
                "failed_tools": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "실패한 도구 이름 목록 (없으면 빈 배열)",
                },
                "error_summary": {
                    "type": "string",
                    "description": "오류 요약 설명 (없으면 빈 문자열)",
                },
                "agent_action": {
                    "type": "string",
                    "description": "에이전트가 취한 조치 요약 (예: '세션 만료 알림 발송', 'URL 수정 후 재실행 불필요', '정상 완료')",
                },
            },
            "required": ["status", "changes_count", "failed_tools", "error_summary", "agent_action"],
        },
    },
]


# ── Claude 에이전트 루프 ──────────────────────────────────────────────────────

def run_agent(exit_code: int, duration_sec: float, config: dict, dry_run: bool):
    client = anthropic.Anthropic()

    system_prompt = f"""당신은 GAH Tool Observer의 AI 에이전트입니다.
tool_observer.py는 Android XTS 도구(CTS, TVTS, VTS, GTS, STS, GSI)의 버전 업데이트를
감시하는 Playwright 기반 웹 스크레이퍼입니다. headless db PC(Ubuntu, 디스플레이 없음)에서 실행됩니다.

분석 절차:
1. read_log를 호출해 실행 로그를 읽는다.
2. 로그에서 실행 결과를 분류한다:
   - success: "[INFO] Tool Observer 완료" 로그 있음 + 오류 없음
   - auth_failed: "세션 만료", "accounts.google.com", "signin", "⚠️ 세션 만료 감지" 등
   - url_changed: 404, "페이지를 찾을 수 없음", 패턴 미발견이 전체 대상에서 발생
   - network_error: timeout, connection refused, DNS 오류 등
   - unknown_error: 위 분류에 해당하지 않는 예외
3. 분류에 따른 조치:
   - auth_failed → send_rsync_alert 호출 (세션 갱신 방법 이메일 발송)
   - url_changed → read_targets 확인 → 로그에서 새 URL 명확히 파악 시 update_target_url 호출
                   새 URL 불명확 시 save_run_result에 url_changed 상태로만 기록
   - 그 외 → 조치 없이 save_run_result 호출
4. 반드시 save_run_result를 마지막에 호출한다.

중요 규칙:
- 로그에 명확한 근거 없이 URL을 추측해서 수정하지 않는다.
- changes_count는 "변경 Xbuilder 감지" 또는 "총 X건" 같은 로그 메시지에서 파악한다.
- dry_run={dry_run}: {'True이므로 알림 발송과 DB 저장은 시뮬레이션만 한다.' if dry_run else 'False이므로 실제 알림 발송과 DB 저장을 실행한다.'}"""

    messages = [
        {
            "role": "user",
            "content": (
                f"tool_observer.py 실행이 완료되었습니다.\n"
                f"exit_code: {exit_code}\n"
                f"실행 시간: {duration_sec:.1f}초\n\n"
                f"로그를 읽어 결과를 분석하고 필요한 조치를 취해주세요."
            ),
        }
    ]

    log("Claude 에이전트 분석 시작...")

    while True:
        response = client.messages.create(
            model=MODEL,
            max_tokens=4096,
            system=system_prompt,
            tools=TOOLS,
            messages=messages,
        )

        messages.append({"role": "assistant", "content": response.content})

        if response.stop_reason == "end_turn":
            log("Claude 에이전트 분석 완료")
            break

        if response.stop_reason != "tool_use":
            log(f"예상치 못한 stop_reason: {response.stop_reason}", "WARN")
            break

        # 도구 호출 처리
        tool_results = []
        for block in response.content:
            if block.type != "tool_use":
                continue

            name = block.name
            inp = block.input
            log(f"도구 호출: {name}({json.dumps(inp, ensure_ascii=False)[:300]})")

            if name == "read_log":
                result = tool_read_log()

            elif name == "read_targets":
                result = tool_read_targets()

            elif name == "update_target_url":
                if dry_run:
                    result = f"[dry-run] URL 수정 생략: [{inp['target_id']}] → {inp['new_url']}"
                    log(result)
                else:
                    result = tool_update_target_url(inp["target_id"], inp["new_url"])

            elif name == "send_rsync_alert":
                result = tool_send_rsync_alert(inp["failed_tools"], config, dry_run)

            elif name == "save_run_result":
                result = tool_save_run_result(
                    status=inp["status"],
                    changes_count=inp.get("changes_count", 0),
                    failed_tools=inp.get("failed_tools", []),
                    error_summary=inp.get("error_summary", ""),
                    agent_action=inp.get("agent_action", ""),
                    exit_code=exit_code,
                    duration_sec=duration_sec,
                    dry_run=dry_run,
                )
            else:
                result = f"알 수 없는 도구: {name}"

            log(f"  → {str(result)[:300]}")
            tool_results.append({
                "type": "tool_result",
                "tool_use_id": block.id,
                "content": str(result),
            })

        messages.append({"role": "user", "content": tool_results})


# ── subprocess 실행 ──────────────────────────────────────────────────────────

def run_observer(dry_run: bool) -> tuple[int, float]:
    cmd = [sys.executable, str(BASE_DIR / "tool_observer.py")]
    if dry_run:
        cmd.append("--dry-run")

    log(f"tool_observer.py 실행 중...{'  [dry-run]' if dry_run else ''}")
    start = time.monotonic()
    result = subprocess.run(cmd)
    duration = time.monotonic() - start
    log(f"tool_observer.py 종료 (exit={result.returncode}, {duration:.1f}초)")
    return result.returncode, duration


# ── 메인 ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Tool Observer AI Agent Runner")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="tool_observer를 dry-run으로 실행, 이메일/DB 저장 생략",
    )
    args = parser.parse_args()

    if not os.environ.get("ANTHROPIC_API_KEY"):
        log("ANTHROPIC_API_KEY 환경 변수가 설정되지 않았습니다", "ERROR")
        sys.exit(1)

    config: dict = {}
    if CONFIG_FILE.exists():
        config = yaml.safe_load(CONFIG_FILE.read_text(encoding="utf-8")) or {}
    else:
        log("config.yaml 없음 — 이메일 알림 비활성화", "WARN")

    # 매 실행마다 로그 초기화
    if LOG_FILE.exists():
        LOG_FILE.write_text("", encoding="utf-8")

    log("=" * 60)
    log(f"Tool Observer Agent 시작{'  [dry-run]' if args.dry_run else ''}")
    log(f"모델: {MODEL}")

    # Phase 1: tool_observer.py 실행
    exit_code, duration_sec = run_observer(dry_run=args.dry_run)

    # Phase 1.5: 감지된 버전을 xts_tool_versions에 저장 (GAH 버전현황 표시용)
    save_detected_versions_to_db(dry_run=args.dry_run)

    # tool_observer.py가 비정상 종료했다면 Claude 분류 결과와 무관하게
    # 무조건 데스크톱 알림을 띄운다. (LLM이 "url_changed"로 오분류해서
    # send_rsync_alert를 호출하지 않는 경우에도 사람에게는 반드시 알려야 함)
    if exit_code != 0 and not args.dry_run:
        notify_desktop(
            "⚠️ Tool Observer 실행 실패",
            f"tool_observer.py가 비정상 종료(exit={exit_code})했습니다.\n"
            f"observer.log를 확인하세요: {LOG_FILE}",
        )

    # Phase 2+3: Claude 분석 + 조치 + DB 저장
    run_agent(
        exit_code=exit_code,
        duration_sec=duration_sec,
        config=config,
        dry_run=args.dry_run,
    )

    log("Tool Observer Agent 완료")
    log("=" * 60)

    # tool_observer.py가 실패했으면 이 프로세스도 실패로 종료해야
    # systemd가 실제로 실패를 감지한다 (그렇지 않으면 매번 exit 0으로 끝나서
    # OnFailure= 안전망이 절대 트리거되지 않는다).
    if exit_code != 0 and not args.dry_run:
        sys.exit(1)


if __name__ == "__main__":
    main()

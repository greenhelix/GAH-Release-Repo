#!/usr/bin/env python3
# Python 3.8 호환: dict[str, str] 등 런타임 평가 없이 문자열로 처리
from __future__ import annotations

"""
Tool Observer — XTS 도구 업데이트 감시 스크립트 (Phase 1)

실행 방법:
  python tool_observer.py           # 전체 감시
  python tool_observer.py --dry-run # 변경 감지만 (이메일 미발송)
  python tool_observer.py --id cts  # 특정 대상만 실행

최초 실행 전: python setup_auth.py 로 구글 세션 저장 필요.
"""

import argparse
import asyncio
import base64
import json
import re
import sys
import traceback
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from typing import Any

import psycopg2
import yaml
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from playwright.async_api import BrowserContext, Page, async_playwright

# ── Android 버전 코드명 / 월 매핑 ─────────────────────────────────────────────
ANDROID_CODENAMES: dict[str, str] = {
    "12": "Snow Cone",
    "13": "Tiramisu",
    "14": "Upside Down Cake",
    "15": "Vanilla Ice Cream",
    "16": "Baklava",
}
MONTH_MAP: dict[str, str] = {
    "January": "01", "February": "02", "March": "03", "April": "04",
    "May": "05", "June": "06", "July": "07", "August": "08",
    "September": "09", "October": "10", "November": "11", "December": "12",
}

# ── 경로 ──────────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent
CONFIG_FILE = BASE_DIR / "config.yaml"
TARGETS_FILE = BASE_DIR / "targets.yaml"
STATE_FILE = BASE_DIR / "state.json"
PROFILE_DIR = BASE_DIR / "auth" / "browser_profile"
GMAIL_CREDENTIALS = BASE_DIR / "credentials.json"
GMAIL_TOKEN = BASE_DIR / "auth" / "gmail_token.json"
GMAIL_SCOPES = ["https://www.googleapis.com/auth/gmail.send"]
LOG_FILE = BASE_DIR / "observer.log"

# ── 로그 ──────────────────────────────────────────────────────────────────────

def log(msg: str, level: str = "INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] [{level}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def log_warn(msg: str):
    log(msg, "WARN")


def log_err(msg: str):
    log(msg, "ERROR")


def notify_desktop(title: str, message: str, urgency: str = "critical"):
    """Gmail 알림 자체가 실패했을 때의 최후 수단 — Google 인증에 의존하지 않는
    로컬 데스크톱 알림. 이메일 발송 실패는 이 경로로만 사람에게 닿는다."""
    import os
    import subprocess
    uid = os.getuid()
    env = os.environ.copy()
    env.setdefault("DISPLAY", ":0")
    env.setdefault("XAUTHORITY", f"/run/user/{uid}/gdm/Xauthority")
    env.setdefault("DBUS_SESSION_BUS_ADDRESS", f"unix:path=/run/user/{uid}/bus")
    try:
        subprocess.run(
            ["notify-send", "-u", urgency, "--expire-time=0", title, message],
            env=env, timeout=10, check=False,
        )
    except Exception as e:
        log_err(f"데스크톱 알림도 실패: {e}")


# ── 파일 I/O ──────────────────────────────────────────────────────────────────

def load_yaml(path: Path) -> dict:
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_state() -> dict:
    if STATE_FILE.exists():
        with open(STATE_FILE, encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_state(state: dict):
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


# ── 공통 유틸 ─────────────────────────────────────────────────────────────────

def extract_last_updated(text: str) -> str | None:
    """'Last updated YYYY-MM-DD UTC' 형식 추출"""
    m = re.search(r"Last updated (\d{4}-\d{2}-\d{2}) UTC", text)
    return m.group(1) if m else None


def platform_includes(platform_text: str, android_ver: int) -> bool:
    """
    'Android X - Y' 또는 'Android X' 범위에 android_ver 포함 여부 반환.
    예: 'Android 13 - 16' → ver=14 → True
    """
    range_m = re.search(r"Android\s+(\d+)\s*[-–]\s*(\d+)", platform_text)
    if range_m:
        lo, hi = int(range_m.group(1)), int(range_m.group(2))
        return lo <= android_ver <= hi
    single_m = re.search(r"Android\s+(\d+)", platform_text)
    if single_m:
        return int(single_m.group(1)) == android_ver
    return False


async def get_page_text(page: Page) -> str:
    """JS 렌더링 완료 후 innerText 전체 반환"""
    return await page.evaluate("() => document.body.innerText")


# ── 대상별 추출 함수 ─────────────────────────────────────────────────────────

async def extract_cts(page: Page, target: dict) -> dict:
    """CTS: source.android.com — 로그인 불필요 공개 페이지"""
    await page.goto(target["url"], wait_until="networkidle", timeout=30000)
    text = await get_page_text(page)

    result: dict[str, Any] = {
        "last_updated": extract_last_updated(text),
        "versions": {},
    }

    for av in target.get("android_versions", []):
        v, pattern = av["version"], av["pattern"]
        m = re.search(pattern, text)
        val = m.group(0) if m else None
        result["versions"][v] = val
        log(f"  CTS Android {v}: {val or '미발견'}")

    return result


async def extract_tvts(page: Page, target: dict) -> dict:
    """TVTS: 릴리즈 노트 페이지 — 맨 위 버전이 최신"""
    await page.goto(target["url"], wait_until="networkidle", timeout=30000)
    text = await get_page_text(page)

    result: dict[str, Any] = {
        "last_updated": extract_last_updated(text),
        "versions": {},
    }

    for pat in target.get("patterns", []):
        m = re.search(pat["pattern"], text)
        val = m.group(0) if m else None
        result["versions"][pat["name"]] = val
        log(f"  TVTS {pat['name']}: {val or '미발견'}")

    return result


async def extract_vts(page: Page, target: dict) -> dict:
    """VTS: VTS 탭에서 android_version별 파일명 추출"""
    await page.goto(target["url"], wait_until="networkidle", timeout=30000)
    text = await get_page_text(page)

    result: dict[str, Any] = {
        "last_updated": extract_last_updated(text),
        "versions": {},
    }

    for av in target.get("android_versions", []):
        v, pattern = av["version"], av["pattern"]
        # findall로 모두 수집 후 정렬 → 가장 높은 r번호가 최신
        matches = re.findall(pattern, text)
        val = sorted(matches)[-1] if matches else None
        result["versions"][v] = val
        log(f"  VTS Android {v}: {val or '미발견'}")

    return result


async def extract_gts(page: Page, target: dict) -> dict:
    """GTS: 테이블 파싱 — Target Platform 범위 기반으로 Android 버전별 File 추출"""
    await page.goto(target["url"], wait_until="load", timeout=60000)

    # DOM에서 테이블 행 추출 (셀 텍스트 배열)
    rows: list[list[str]] = await page.evaluate("""
        () => {
            const result = [];
            document.querySelectorAll('table tr').forEach(tr => {
                const cells = Array.from(tr.querySelectorAll('td, th'))
                                   .map(td => td.innerText.trim());
                if (cells.length >= 2) result.push(cells);
            });
            return result;
        }
    """)

    text = await get_page_text(page)

    result: dict[str, Any] = {
        "last_updated": extract_last_updated(text),
        "versions": {},
    }

    log(f"  GTS 테이블 행 {len(rows)}개 발견")

    for av in target.get("android_versions", []):
        v = av["version"]
        ver_int = int(v)
        best_file = None
        best_series = -1

        for row in rows:
            # 테이블 컬럼 추정: [Series, Platform, File] or [Platform, File] 등
            # File 셀에서 GTS_X.X_rY 패턴 탐색
            for cell in row:
                # GTS_13.1_r2 형식과 GTS_12_r3 (minor 없음) 형식 모두 지원
                gts_m = re.search(r"GTS_(\d+)(?:\.(\d+))?_r\d+", cell)
                if not gts_m:
                    continue
                minor = int(gts_m.group(2)) if gts_m.group(2) else 0
                series_num = int(gts_m.group(1)) * 100 + minor

                # 같은 행의 다른 셀에서 Platform 정보 확인
                row_text = " | ".join(row)
                if platform_includes(row_text, ver_int):
                    if series_num > best_series:
                        best_series = series_num
                        best_file = re.search(r"GTS_\d+(?:\.\d+)?_r\d+", cell).group(0)

        result["versions"][v] = best_file
        log(f"  GTS Android {v}: {best_file or '미발견'}")

    return result


async def extract_sts(page: Page, target: dict) -> dict:
    """
    STS: 'Get Latest STS Tests' 버튼 클릭 → Google Drive 진입.
    Drive 파일 목록에서 Android 14/16 zip 패턴 탐색.
    """
    await page.goto(target["url"], wait_until="load", timeout=60000)
    text_main = await get_page_text(page)

    result: dict[str, Any] = {
        "last_updated": extract_last_updated(text_main),
        "versions": {},
    }

    # 메인 페이지 + 모든 프레임에서 버튼 탐색
    target_frame = None
    target_btn = None
    for frame in page.frames:
        try:
            b = frame.get_by_text("Get Latest STS Tests", exact=False)
            cnt = await b.count()
            if cnt > 0:
                target_frame = frame
                target_btn = b
                break
        except Exception:
            continue

    if target_btn is None:
        log_warn("  STS: 'Get Latest STS Tests' 버튼 미발견")
        return result

    # href 직접 추출 후 이동 (클릭 대신)
    drive_url = await target_btn.first.evaluate(
        "el => el.tagName === 'A' ? el.href : (el.closest('a') ? el.closest('a').href : null)"
    )

    log("  STS: Google Drive 이동 중...")
    try:
        if drive_url:
            async with page.context.expect_page(timeout=10000) as new_page_info:
                await target_btn.first.click()
            drive_page = await new_page_info.value
        else:
            async with page.context.expect_page(timeout=10000) as new_page_info:
                await target_btn.first.click()
            drive_page = await new_page_info.value
    except Exception:
        drive_page = page

    # Drive UI가 로드될 때까지 대기 (파일 목록 렌더링)
    try:
        await drive_page.wait_for_load_state("networkidle", timeout=30000)
        # Drive의 파일 목록 요소가 나타날 때까지 추가 대기
        await drive_page.wait_for_timeout(3000)
    except Exception:
        pass

    drive_text = await drive_page.evaluate("() => document.body.innerText")

    for av in target.get("android_versions", []):
        v, pattern = av["version"], av["pattern"]
        match_iter = list(re.finditer(pattern, drive_text))
        if match_iter:
            # r번호 기준 최신 선택 (예: sts-r52 > sts-r50)
            best = max(match_iter, key=lambda m: int(re.search(r"sts-r(\d+)", m.group(0)).group(1)))
            val = best.group(0)
            # Date modified 추출: 파일명 이후 토큰에서 "Jun 2" 형식 탐색
            after = drive_text[best.end():]
            date_modified = None
            for token in [t.strip() for t in after.split("\n")[:10] if t.strip()]:
                if re.match(r"^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}$", token):
                    date_modified = token
                    break
        else:
            val = None
            date_modified = None
        result["versions"][v] = {"file": val, "date_modified": date_modified}
        log(f"  STS Android {v}: {val or '미발견'} (날짜: {date_modified or '미발견'})")

    # 새 탭이었으면 닫기
    if drive_page is not page:
        await drive_page.close()

    return result


async def extract_gsi(page: Page, target: dict) -> dict:
    """
    GSI: 전체 페이지에서 Build 위치 기반으로 Android 버전 귀속.
    페이지 상단 네비게이션과 본문이 분리되어 있어 섹션 파싱 대신 사용.
    """
    await page.goto(target["url"], wait_until="load", timeout=60000)

    # JS 동적 콘텐츠 렌더링 대기
    try:
        await page.wait_for_function(
            "() => document.body.innerText.includes('released on')",
            timeout=15000,
        )
    except Exception:
        log_warn("  GSI: 콘텐츠 로딩 대기 타임아웃")

    text = await get_page_text(page)

    result: dict[str, Any] = {
        "last_updated": extract_last_updated(text),
        "versions": {},
    }

    # 각 Build 패턴의 위치와 직전 Android 버전 번호를 매핑
    # "Android X" 직후 처음 등장하는 Build가 해당 버전의 최신 빌드
    target_versions = {av["version"] for av in target.get("android_versions", [])}

    # 버전별 첫 번째 Build/Patch 위치 수집
    version_build: dict[str, str | None] = {}
    version_patch: dict[str, str | None] = {}

    for m in re.finditer(r"Build\s+\d+\s*\(released on [^)]+\)", text):
        before = text[:m.start()]
        # 직전에 등장한 Android 버전 번호 탐색
        android_m = re.findall(r"Android\s+(\d+)", before)
        if not android_m:
            continue
        ver = android_m[-1]
        if ver in target_versions and ver not in version_build:
            version_build[ver] = m.group(0)

    for m in re.finditer(r"Security patch level is updated to\s+([\d-]+)", text):
        before = text[:m.start()]
        android_m = re.findall(r"Android\s+(\d+)", before)
        if not android_m:
            continue
        ver = android_m[-1]
        if ver in target_versions and ver not in version_patch:
            version_patch[ver] = m.group(1)

    for av in target.get("android_versions", []):
        v = av["version"]
        ver_data = {
            "build": version_build.get(v),
            "security_patch": version_patch.get(v),
        }
        result["versions"][v] = ver_data
        log(f"  GSI Android {v}: {ver_data}")

    return result


# ── 추출 함수 라우팅 ──────────────────────────────────────────────────────────

EXTRACTORS = {
    "cts": extract_cts,
    "tvts": extract_tvts,
    "vts": extract_vts,
    "gts": extract_gts,
    "sts": extract_sts,
    "gsi": extract_gsi,
}

# tool_observer.py 대상 id → xts_tool_versions.suite_name
# [주의] agent_runner.py의 SUITE_NAME_MAP과 동일 매핑을 중복 유지 중.
#        Phase 2(core/tools 모듈 분리)에서 ToolDefinition으로 통합 예정.
SUITE_NAME_MAP = {
    "cts": "CTS",
    "vts": "VTS",
    "gts": "GTS",
    "sts": "STS",
    "tvts": "TVTS",
    "gsi": "GSI",
}

# ── 버전 문자열 정규화 (DB 비교용) ────────────────────────────────────────────
# agent_runner.py:_parse_version_entry와 동일 로직 — DB에 실제 저장되는 형식과
# 일치해야 "이미 본 버전인지" 비교가 정확하므로 두 곳 모두 수정 시 함께 반영할 것.

def _parse_version_entry(tool_id: str, raw_val) -> tuple[str | None, str | None]:
    """스크래핑 원시값을 (xts_tool_versions.version 형식 문자열, notes)로 정규화."""
    if raw_val is None:
        return None, None

    if isinstance(raw_val, dict):
        # STS: {"file": "android-sts-14_sts-r52-...", "date_modified": "Jun 2"}
        if "file" in raw_val:
            file_str = raw_val.get("file") or ""
            date_mod = raw_val.get("date_modified")
            m = re.search(r"android-sts-(\d+)_sts-r(\d+)", file_str)
            if m:
                return f"{m.group(1)}_sts-r{m.group(2)}", date_mod
            return None, None
        # GSI: {"build": "Build XXXXXXX (released on ...)", "security_patch": "..."}
        if "build" in raw_val:
            build = raw_val.get("build") or ""
            spl = raw_val.get("security_patch")
            m = re.search(r"Build\s+(\d+)", build)
            if m:
                return f"build{m.group(1)}", spl or None
            return None, None
        return None, None

    raw = str(raw_val)
    # CTS: android-cts-14.0_r12
    m = re.match(r"android-cts-(\d+\.\d+)_r(\d+)", raw)
    if m:
        return f"{m.group(1)}_r{m.group(2)}", None
    # VTS: VTS-14_r12_arm
    m = re.match(r"VTS-(\d+)_r(\d+)_arm", raw, re.IGNORECASE)
    if m:
        return f"{m.group(1)}_r{m.group(2)}", None
    # GTS: GTS_13.1_r2 or GTS_14_r1
    m = re.match(r"GTS_(\d+)(?:\.(\d+))?_r(\d+)", raw)
    if m:
        series = m.group(1) + (f".{m.group(2)}" if m.group(2) else "")
        return f"{series}_r{m.group(3)}", None
    # TVTS: TVTS 2.18 R1
    m = re.match(r"TVTS\s+(\d+\.\d+)\s+R(\d+)", raw)
    if m:
        return f"{m.group(1)}_r{m.group(2)}", None
    return raw, None


# ── DB 연결 ───────────────────────────────────────────────────────────────────

def _get_db_conn(config: dict):
    db = config.get("db", {})
    return psycopg2.connect(
        host=db.get("host", "localhost"),
        port=int(db.get("port", 5432)),
        dbname=db.get("dbname", "gah"),
        user=db.get("user", "gah_user"),
        password=db.get("password", ""),
    )


def fetch_known_versions(config: dict) -> dict[str, set[str]] | None:
    """xts_tool_versions에 이미 기록된 (suite_name -> version 집합) 조회.
    반환값이 None이면 DB 조회 자체가 실패한 것 — 빈 dict({})와 구분해야 한다.
    호출부는 None을 "신규 없음"이 아니라 "판단 불가"로 취급해 크게 실패 처리할 것."""
    try:
        conn = _get_db_conn(config)
        cur = conn.cursor()
        cur.execute("SELECT suite_name, version FROM xts_tool_versions")
        rows = cur.fetchall()
        cur.close()
        conn.close()
    except Exception as e:
        log_err(f"xts_tool_versions 조회 실패: {e}")
        return None

    known: dict[str, set[str]] = {}
    for suite_name, version in rows:
        known.setdefault(suite_name, set()).add(version)
    return known


# ── 변경 감지 ─────────────────────────────────────────────────────────────────

def detect_changes(tid: str, known: set[str] | None, curr: dict, force: bool = False) -> list[str]:
    """
    DB(xts_tool_versions)에 이미 기록된 버전 집합(known) 기준으로 신규 버전만 변경으로 판정.
    state.json이 아니라 DB가 "이미 본 버전인지"의 유일한 기준이다 — 로컬 파일이
    깨지거나 비어있어도 오탐지(false "변경없음")가 구조적으로 발생하지 않는다.
    known이 비어있으면(해당 suite가 DB에 아직 없음) 유효한 값 전부를 신규로 처리한다.
    force=True: known과 무관하게 모든 현재값을 신규 변경으로 처리 (test-email용).
    last_updated는 changes 목록에서 제외 — 카드 헤더에만 표시.
    """
    changes = []
    curr_v: dict = curr.get("versions", {})
    known = known or set()

    for key, curr_val in curr_v.items():
        version_str, _notes = _parse_version_entry(tid, curr_val)
        if version_str is None:
            continue  # 추출 실패/정규화 불가 — 비교 대상 아님 (변경도, 무변경도 아님)
        if not force and version_str in known:
            continue  # 이미 DB에 기록된 버전 — 변경 아님

        if isinstance(curr_val, dict):
            for sub_key, sub_val in curr_val.items():
                if sub_val is not None:
                    changes.append(f"Android {key} [{sub_key}]: None → {sub_val}")
        else:
            changes.append(f"Android {key}: None → {curr_val}")

    return changes


# ── 버전 표시 포맷 ────────────────────────────────────────────────────────────

def format_version(raw: str) -> str:
    """원시 버전 문자열을 간결한 표시형으로 변환"""
    if not raw or raw in ("—", "None", "none"):
        return "—"
    # CTS: android-cts-12.0_r16
    m = re.match(r"android-cts-(\d+)\.\d+_r(\d+)", raw)
    if m:
        return f"CTS {m.group(1)} R{m.group(2)}"
    # VTS: VTS-12_r16_arm
    m = re.match(r"VTS-(\d+)_r(\d+)_arm", raw, re.IGNORECASE)
    if m:
        return f"VTS {m.group(1)} R{m.group(2)}"
    # GTS: GTS_13.1_r2 또는 GTS_12_r3
    m = re.match(r"GTS_(\d+)(?:\.(\d+))?_r(\d+)", raw)
    if m:
        series = m.group(1) + (f".{m.group(2)}" if m.group(2) else "")
        return f"GTS {series} R{m.group(3)}"
    # STS: android-sts-14_sts-r50-linux-arm64.zip
    m = re.match(r"android-sts-(\d+)_sts-r(\d+)-", raw)
    if m:
        return f"STS {m.group(1)} R{m.group(2)}"
    # GSI build: Build 15016931 (released on March 4, 2026)
    m = re.match(r"Build\s+(\d+)\s*\(released on (\w+)\s+(\d+),\s+(\d{4})\)", raw)
    if m:
        mo = MONTH_MAP.get(m.group(2), "??")
        return f"{m.group(1)} ({m.group(4)[2:]}-{mo}-{m.group(3).zfill(2)})"
    # Security patch: 2025-12-01
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})$", raw.strip())
    if m:
        return f"SPL: {m.group(1)[2:]}-{m.group(2)}-{m.group(3)}"
    return raw


def format_label(label: str) -> str:
    """변경 라벨을 표시용으로 변환 (간결하게)"""
    label = label.strip().replace("📅 ", "")
    # Android X [build]
    m = re.match(r"Android\s+(\d+)\s*\[build\]", label)
    if m:
        return f"Android {m.group(1)} Build"
    # Android X [security_patch]
    m = re.match(r"Android\s+(\d+)\s*\[security_patch\]", label)
    if m:
        return f"Android {m.group(1)} SPL"
    # Android X [file]
    m = re.match(r"Android\s+(\d+)\s*\[file\]", label)
    if m:
        return f"Android {m.group(1)} 파일"
    # Android X [date_modified]
    m = re.match(r"Android\s+(\d+)\s*\[date_modified\]", label)
    if m:
        return f"Android {m.group(1)} 갱신일"
    # Android X (숫자만)
    m = re.match(r"Android\s+(\d+)$", label)
    if m:
        return f"Android {m.group(1)}"
    if "Latest" in label:
        return "Latest"
    return label


def _fmt_last_updated(raw: str | None) -> str:
    """'2026-04-09' → '26-04-09', None → '—'"""
    if not raw:
        return "—"
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", raw)
    if m:
        return f"{m.group(1)[2:]}-{m.group(2)}-{m.group(3)}"
    return raw


# ── 이메일 발송 ───────────────────────────────────────────────────────────────

def _parse_change_row(chg: str) -> tuple[str, str, str]:
    """변경 문자열을 (포맷된 라벨, 포맷된 이전값, 포맷된 이후값)으로 파싱"""
    if " → " in chg:
        label, rest = chg.split(": ", 1) if ": " in chg else ("", chg)
        old, new = rest.split(" → ", 1)
        return format_label(label), format_version(old.strip()), format_version(new.strip())
    return chg, "", ""


def _fetch_quarterly_schedule(config: dict) -> list[dict]:
    """DB에서 오늘 이후 분기 일정 조회 (최대 4건)"""
    db = config.get("db", {})
    try:
        conn = psycopg2.connect(
            host=db.get("host", "localhost"),
            port=int(db.get("port", 5432)),
            dbname=db.get("dbname", "gah"),
            user=db.get("user", "gah_user"),
            password=db.get("password", ""),
        )
        cur = conn.cursor()
        cur.execute("""
            SELECT year, quarter, announce_date, required_use_date,
                   cts_next, vts_next, gts_next, notes
            FROM xts_quarterly_schedule
            WHERE required_use_date >= CURRENT_DATE - INTERVAL '30 days'
            ORDER BY year, quarter
            LIMIT 4
        """)
        rows = cur.fetchall()
        cur.close()
        conn.close()
        return [
            {
                "year": r[0], "quarter": r[1],
                "announce_date": r[2], "required_use_date": r[3],
                "cts_next": r[4], "vts_next": r[5], "gts_next": r[6], "notes": r[7],
            }
            for r in rows
        ]
    except Exception as e:
        log_warn(f"분기별 일정 조회 실패: {e}")
        return []


def _build_schedule_html(schedule: list[dict]) -> str:
    """분기별 일정 HTML 테이블"""
    if not schedule:
        return ""

    today = datetime.now().date()
    rows = ""
    for s in schedule:
        req_date = s["required_use_date"]
        is_upcoming = req_date and req_date >= today
        row_bg = "#FFF8E1" if is_upcoming else "#fafafa"
        badge = (
            '<span style="background:#F57F17;color:#fff;font-size:10px;'
            'padding:2px 6px;border-radius:8px;margin-left:6px">예정</span>'
            if is_upcoming else ""
        )
        rows += f"""
        <tr style="background:{row_bg}">
          <td style="padding:8px 12px;font-size:13px;font-weight:600;white-space:nowrap">
            {s['year']} Q{s['quarter']}{badge}
          </td>
          <td style="padding:8px 12px;font-size:12px;color:#555;white-space:nowrap">{s['announce_date'] or '—'}</td>
          <td style="padding:8px 12px;font-size:12px;color:#B71C1C;font-weight:bold;white-space:nowrap">{s['required_use_date'] or '—'}</td>
          <td style="padding:8px 12px;font-size:12px;font-family:monospace;color:#1565C0">{s['cts_next'] or '—'}</td>
          <td style="padding:8px 12px;font-size:12px;font-family:monospace;color:#2E7D32">{s['vts_next'] or '—'}</td>
          <td style="padding:8px 12px;font-size:12px;font-family:monospace;color:#6A1B9A">{s['gts_next'] or '—'}</td>
          <td style="padding:8px 12px;font-size:12px;color:#777">{s['notes'] or ''}</td>
        </tr>"""

    th = 'style="padding:6px 12px;text-align:left;font-size:11px;color:#666;font-weight:600;border-bottom:2px solid #e0e0e0;background:#f5f5f5"'
    return f"""
    <div style="margin-top:24px">
      <div style="font-size:14px;font-weight:700;color:#333;margin-bottom:10px;
                  padding-bottom:6px;border-bottom:2px solid #F57F17">분기별 업데이트 일정</div>
      <div style="background:#fff;border-radius:8px;border:1px solid #e0e0e0;overflow:hidden">
        <table width="100%" cellpadding="0" cellspacing="0">
          <tr>
            <th {th}>분기</th>
            <th {th}>공지일</th>
            <th {th}>필수 적용일</th>
            <th {th}>CTS</th>
            <th {th}>VTS</th>
            <th {th}>GTS</th>
            <th {th}>비고</th>
          </tr>
          {rows}
        </table>
      </div>
    </div>"""


def build_email_html(changes_report: list[dict], state: dict | None = None,
                     targets_all: list[dict] | None = None,
                     config: dict | None = None) -> str:
    """변경 감지 이메일 — 전체 현황 테이블 + 변경 카드"""
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    total = sum(len(r["changes"]) for r in changes_report)

    # ── 전체 현황 테이블 ──────────────────────────────────────────────────────
    status_table = (
        _build_status_table_html(state, targets_all)
        if state is not None and targets_all is not None else ""
    )
    status_section = (
        f'<div style="margin-bottom:28px">'
        f'<div style="font-size:14px;font-weight:700;color:#333;margin-bottom:10px'
        f';padding-bottom:6px;border-bottom:2px solid #1565C0">전체 현황</div>'
        f'{status_table}</div>'
    ) if status_table else ""

    # ── 변경 카드 ─────────────────────────────────────────────────────────────
    cards_html = ""
    for item in changes_report:
        lu = _fmt_last_updated(item.get("last_updated"))
        lu_badge = (
            f'<span style="color:#90CAF9;font-size:12px;margin-left:10px">'
            f'갱신: {lu}</span>'
        ) if lu != "—" else ""

        rows = ""
        for chg in item["changes"]:
            label, old, new = _parse_change_row(chg)
            if old == "—":
                # 이전 기록 없음 — 신규 감지
                old_cell = '<span style="background:#FFF3E0;color:#E65100;font-size:11px;padding:2px 6px;border-radius:3px;font-family:sans-serif">신규</span>'
            else:
                old_cell = f'<span style="color:#aaa;font-family:monospace;text-decoration:line-through">{old}</span>'
            rows += f"""
            <tr>
              <td style="padding:9px 14px;color:#555;font-size:13px;border-bottom:1px solid #f0f0f0;width:140px;font-weight:500">{label}</td>
              <td style="padding:9px 12px;font-size:13px;border-bottom:1px solid #f0f0f0">{old_cell}</td>
              <td style="padding:9px 8px;color:#bbb;font-size:16px;border-bottom:1px solid #f0f0f0;font-weight:bold">→</td>
              <td style="padding:9px 14px;color:#1B5E20;font-size:13px;border-bottom:1px solid #f0f0f0;font-family:monospace;font-weight:bold">{new}</td>
            </tr>"""

        cards_html += f"""
        <div style="background:#fff;border-radius:8px;border:1px solid #e0e0e0;margin-bottom:14px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.06)">
          <div style="background:#1565C0;padding:10px 16px;display:flex;align-items:center">
            <span style="color:#fff;font-weight:bold;font-size:15px">{item['name']}</span>
            {lu_badge}
            <span style="background:#0D47A1;color:#BBDEFB;font-size:12px;padding:2px 8px;border-radius:10px;margin-left:auto">{len(item['changes'])}건 변경</span>
          </div>
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr style="background:#f8f9fa">
              <th style="padding:6px 14px;text-align:left;font-size:11px;color:#999;font-weight:600;width:140px;letter-spacing:0.5px">항목</th>
              <th style="padding:6px 12px;text-align:left;font-size:11px;color:#999;font-weight:600">이전</th>
              <th style="width:28px"></th>
              <th style="padding:6px 14px;text-align:left;font-size:11px;color:#999;font-weight:600">현재</th>
            </tr>
            {rows}
          </table>
        </div>"""

    changes_section = (
        f'<div style="margin-top:8px">'
        f'<div style="font-size:14px;font-weight:700;color:#333;margin-bottom:10px'
        f';padding-bottom:6px;border-bottom:2px solid #E53935">변경 내역</div>'
        f'{cards_html}</div>'
    )

    schedule = _fetch_quarterly_schedule(config) if config else []
    schedule_section = _build_schedule_html(schedule)

    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0;background:#f0f2f5">
  <div style="max-width:740px;margin:24px auto;padding:0 16px">

    <div style="background:linear-gradient(135deg,#1565C0,#0D47A1);border-radius:10px 10px 0 0;padding:22px 28px">
      <div style="color:#fff;font-size:20px;font-weight:bold;letter-spacing:-0.3px">XTS 도구 업데이트 감지</div>
      <div style="color:#90CAF9;font-size:13px;margin-top:5px">검사 일시: {today}</div>
    </div>

    <div style="background:#E53935;padding:11px 24px">
      <span style="color:#fff;font-weight:bold;font-size:14px">⚡ 총 {total}건의 변경사항이 감지되었습니다.</span>
    </div>

    <div style="background:#fff;border-radius:0 0 10px 10px;padding:24px 24px 20px;border:1px solid #e0e0e0;border-top:none">
      {status_section}
      {changes_section}
      {schedule_section}
    </div>

    <div style="text-align:center;padding:14px;color:#aaa;font-size:11px">
      GAH Tool Observer — 자동 발송 메일입니다.
    </div>
  </div>
</body>
</html>"""


def _gsi_cell(ver_dict: dict | None) -> str:
    """GSI 버전 딕셔너리를 한 셀 텍스트로 변환"""
    if not ver_dict:
        return "—"
    build = format_version(ver_dict.get("build") or "")
    spl_raw = ver_dict.get("security_patch")
    spl = format_version(spl_raw) if spl_raw else ""
    parts = []
    if build and build != "—":
        parts.append(build)
    if spl and spl != "—":
        parts.append(spl)
    return "<br>".join(parts) if parts else "—"


def _build_status_table_html(state: dict, targets_all: list[dict]) -> str:
    """전 도구 버전 현황 매트릭스 테이블 HTML"""
    th = (
        '<th style="padding:8px 12px;text-align:left;font-size:12px;'
        'color:#555;font-weight:600;border-bottom:2px solid #e0e0e0">'
    )
    header = (
        f"{th}도구</th>"
        f"{th}Android 12</th>"
        f"{th}Android 14</th>"
        f"{th}Android 16</th>"
        f"{th}last update</th>"
    )

    rows = ""
    for i, target in enumerate(targets_all):
        tid = target["id"]
        curr = state.get(tid, {})
        versions = curr.get("versions", {})
        lu = _fmt_last_updated(curr.get("last_updated"))
        bg = "#ffffff" if i % 2 == 0 else "#f9f9f9"

        td_base = (
            f'style="padding:9px 12px;font-size:13px;border-bottom:1px solid #f0f0f0;'
            f'vertical-align:top;background:{bg}"'
        )
        td_mono = (
            f'style="padding:9px 12px;font-size:12px;font-family:monospace;'
            f'color:#2E7D32;border-bottom:1px solid #f0f0f0;vertical-align:top;background:{bg}"'
        )
        td_none = (
            f'style="padding:9px 12px;font-size:12px;font-family:monospace;'
            f'color:#bbb;border-bottom:1px solid #f0f0f0;vertical-align:top;background:{bg}"'
        )
        td_date = (
            f'style="padding:9px 12px;font-size:12px;color:#888;'
            f'border-bottom:1px solid #f0f0f0;vertical-align:top;background:{bg};white-space:nowrap"'
        )

        def ver_cell(key: str) -> str:
            if tid == "sts" and key == "12":
                return f'<td {td_mono}>STS 12 R36</td>'
            val = versions.get(key)
            if val is None:
                return f'<td {td_none}>업데이트 안됨</td>'
            if isinstance(val, dict):
                # STS: {"file": ..., "date_modified": ...}
                if "file" in val:
                    fv = format_version(str(val.get("file") or ""))
                    dm = val.get("date_modified") or ""
                    if fv and fv != "—":
                        dm_html = (
                            f'<br><span style="color:#888;font-size:11px;font-family:sans-serif">{dm}</span>'
                            if dm else ""
                        )
                        return f'<td {td_mono}>{fv}{dm_html}</td>'
                    return f'<td {td_none}>업데이트 안됨</td>'
                # GSI: {"build": ..., "security_patch": ...}
                cell = _gsi_cell(val)
                return f'<td {td_mono}>{cell}</td>' if cell != "—" else f'<td {td_none}>업데이트 안됨</td>'
            fv = format_version(str(val))
            return f'<td {td_mono}>{fv}</td>'

        if "Latest Version" in versions:
            latest = format_version(str(versions.get("Latest Version") or "—"))
            val_html = latest if latest != "—" else '<span style="color:#bbb">업데이트 안됨</span>'
            rows += (
                f'<tr>'
                f'<td {td_base}><b>{target["name"]}</b></td>'
                f'<td colspan="3" style="padding:9px 12px;font-size:12px;'
                f'font-family:monospace;color:#2E7D32;border-bottom:1px solid #f0f0f0;'
                f'vertical-align:top;background:{bg}">'
                f'<span style="font-size:10px;color:#888;font-family:sans-serif;'
                f'margin-right:6px;font-weight:normal">전 버전 공통</span>{val_html}</td>'
                f'<td {td_date}>{lu}</td>'
                f'</tr>'
            )
        else:
            rows += (
                f'<tr>'
                f'<td {td_base}><b>{target["name"]}</b></td>'
                f'{ver_cell("12")}{ver_cell("14")}{ver_cell("16")}'
                f'<td {td_date}>{lu}</td>'
                f'</tr>'
            )

    return f"""
    <div style="background:#fff;border-radius:8px;border:1px solid #e0e0e0;overflow:hidden">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr style="background:#f0f4f8">{header}</tr>
        {rows}
      </table>
    </div>"""


def build_no_change_email(state: dict, targets_all: list[dict], config: dict | None = None) -> str:
    """변경 없음 — 전 도구 버전 현황 매트릭스"""
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    table_html = _build_status_table_html(state, targets_all)
    schedule = _fetch_quarterly_schedule(config) if config else []
    schedule_section = _build_schedule_html(schedule)

    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0;background:#f0f2f5">
  <div style="max-width:740px;margin:24px auto;padding:0 16px">

    <div style="background:linear-gradient(135deg,#2E7D32,#1B5E20);border-radius:10px 10px 0 0;padding:22px 28px">
      <div style="color:#fff;font-size:20px;font-weight:bold;letter-spacing:-0.3px">XTS 도구 상태 점검</div>
      <div style="color:#A5D6A7;font-size:13px;margin-top:5px">검사 일시: {today}</div>
    </div>

    <div style="background:#2E7D32;padding:11px 24px">
      <span style="color:#fff;font-weight:bold;font-size:14px">✅ 변경 없음 — 모든 도구가 최신 상태입니다.</span>
    </div>

    <div style="background:#fff;border-radius:0 0 10px 10px;padding:24px;border:1px solid #e0e0e0;border-top:none">
      <div style="font-size:14px;font-weight:700;color:#333;margin-bottom:10px;padding-bottom:6px;border-bottom:2px solid #2E7D32">전체 현황</div>
      {table_html}
      {schedule_section}
    </div>

    <div style="text-align:center;padding:14px;color:#aaa;font-size:11px">
      GAH Tool Observer — 자동 발송 메일입니다.
    </div>
  </div>
</body>
</html>"""


def build_auth_alert_email(failed_tools: list[str], config: dict | None = None) -> str:
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    tool_list = "".join(f"<li>{t}</li>" for t in failed_tools)
    schedule = _fetch_quarterly_schedule(config) if config else []
    schedule_section = _build_schedule_html(schedule)
    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0;background:#f5f5f5">
  <div style="max-width:680px;margin:24px auto;padding:0 16px">
    <div style="background:#B71C1C;border-radius:10px 10px 0 0;padding:20px 24px">
      <div style="color:#fff;font-size:20px;font-weight:bold">⚠️ 세션 만료 — 재인증 필요</div>
      <div style="color:#EF9A9A;font-size:13px;margin-top:4px">감지 일시: {today}</div>
    </div>
    <div style="background:#fff;border-radius:0 0 8px 8px;border:1px solid #e0e0e0;padding:20px 24px">
      <p style="color:#333;font-size:14px">아래 도구의 데이터를 가져오지 못했습니다. Google 로그인 세션이 만료된 것으로 보입니다.</p>
      <ul style="color:#B71C1C;font-size:14px">{tool_list}</ul>
      {schedule_section}
    </div>
    <div style="text-align:center;padding:16px;color:#aaa;font-size:11px">GAH Tool Observer — 자동 발송 메일입니다.</div>
  </div>
</body>
</html>"""


def build_db_error_email(error_msg: str) -> str:
    """xts_tool_versions 조회 자체가 실패했을 때 — diff 기준을 세울 수 없어
    스크래핑을 아예 건너뛰었다는 뜻. '변경 없음'과 절대 혼동되면 안 되는 상태."""
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0;background:#f5f5f5">
  <div style="max-width:680px;margin:24px auto;padding:0 16px">
    <div style="background:#B71C1C;border-radius:10px 10px 0 0;padding:20px 24px">
      <div style="color:#fff;font-size:20px;font-weight:bold">🛑 DB 조회 실패 — 실행 중단</div>
      <div style="color:#EF9A9A;font-size:13px;margin-top:4px">감지 일시: {today}</div>
    </div>
    <div style="background:#fff;border-radius:0 0 8px 8px;border:1px solid #e0e0e0;padding:20px 24px">
      <p style="color:#333;font-size:14px">
        xts_tool_versions 조회에 실패해 어떤 버전이 신규인지 판단할 기준이 없습니다.
        오탐지를 막기 위해 스크래핑을 건너뛰었습니다 — 실제로는 변경이 있었을 수 있습니다.
      </p>
      <pre style="background:#fafafa;border:1px solid #eee;border-radius:6px;padding:12px;
                  color:#B71C1C;font-size:12px;white-space:pre-wrap">{error_msg}</pre>
      <p style="color:#333;font-size:14px">PostgreSQL 서비스 상태를 확인하세요: <code>sudo systemctl status postgresql</code></p>
    </div>
    <div style="text-align:center;padding:16px;color:#aaa;font-size:11px">GAH Tool Observer — 자동 발송 메일입니다.</div>
  </div>
</body>
</html>"""


def is_auth_failed(curr: dict, target: dict) -> bool:
    """인증 실패 여부 판단: auth_required 대상에서 모든 값이 None/미발견이면 True"""
    if not target.get("auth_required", False):
        return False
    versions = curr.get("versions", {})
    if not versions:
        return True
    # 모든 버전이 None이거나 dict인데 전부 None이면 실패로 판단
    for v in versions.values():
        if isinstance(v, dict):
            if any(val is not None for val in v.values()):
                return False
        elif v is not None:
            return False
    return True


def _get_gmail_service():
    """Gmail API 서비스 객체 반환 (최초 실행 시 OAuth2 인증 브라우저 열림)"""
    creds = None
    if GMAIL_TOKEN.exists():
        creds = Credentials.from_authorized_user_file(str(GMAIL_TOKEN), GMAIL_SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                str(GMAIL_CREDENTIALS), GMAIL_SCOPES
            )
            creds = flow.run_local_server(port=0)
        GMAIL_TOKEN.parent.mkdir(parents=True, exist_ok=True)
        GMAIL_TOKEN.write_text(creds.to_json())
    return build("gmail", "v1", credentials=creds)


def send_email(config: dict, changes_report: list[dict],
               state: dict | None = None, targets_all: list[dict] | None = None,
               auth_failed_tools: list[str] | None = None,
               db_error: str | None = None):
    smtp_cfg = config["smtp"]
    today = datetime.now().strftime("%Y-%m-%d")

    if db_error:
        subject = f"[GAH] 🛑 Tool Observer DB 조회 실패 {today}"
        html = build_db_error_email(db_error)
    elif auth_failed_tools:
        subject = f"[GAH] ⚠️ 세션 만료 — 재인증 필요 {today}"
        html = build_auth_alert_email(auth_failed_tools, config)
    elif bool(changes_report):
        total = sum(len(r["changes"]) for r in changes_report)
        subject = f"[GAH] XTS 업데이트 감지 {total}건 — {today}"
        html = build_email_html(changes_report, state, targets_all, config)
    else:
        subject = f"[GAH] XTS 변경 없음 — {today}"
        html = build_no_change_email(state or {}, targets_all or [], config)

    # 세션 만료/DB 오류 알림은 alert_to(관리자 전용)로만 발송
    if auth_failed_tools or db_error:
        recipients = smtp_cfg.get("alert_to") or smtp_cfg["to"]
    else:
        recipients = smtp_cfg["to"]

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = smtp_cfg["from"]
    msg["To"] = ", ".join(recipients)
    msg.attach(MIMEText(html, "html", "utf-8"))

    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    try:
        service = _get_gmail_service()
        service.users().messages().send(userId="me", body={"raw": raw}).execute()
        log(f"이메일 발송 완료 → {recipients}")
    except Exception as e:
        log_err(f"이메일 발송 실패 — Gmail 인증 문제로 추정: {e}")
        notify_desktop(
            "⚠️ Tool Observer 이메일 발송 실패",
            "Gmail 인증 오류로 알림 메일을 못 보냈습니다. 터미널에서 재인증하세요:\n"
            "cd ~/xts/gah_code/python/tool_observer\n"
            "rm auth/gmail_token.json && ./venv/bin/python tool_observer.py --test-email\n"
            f"오류: {e}",
        )
        raise


# ── 메인 ──────────────────────────────────────────────────────────────────────

async def run(target_ids: list[str] | None, dry_run: bool, test_email: bool = False):
    config = load_yaml(CONFIG_FILE) if CONFIG_FILE.exists() else {}
    targets_all: list[dict] = load_yaml(TARGETS_FILE)["targets"]
    state = load_state()

    # 특정 ID 필터
    if target_ids:
        targets = [t for t in targets_all if t["id"] in target_ids]
        if not targets:
            log_err(f"대상 ID 미발견: {target_ids}")
            return
    else:
        targets = targets_all

    log("=" * 60)
    log(f"Tool Observer 시작 — 대상 {len(targets)}개{'  [dry-run]' if dry_run else ''}")

    # ── DB 우선 조회: 이게 유일한 "신규 버전인지" 판단 기준 ──────────────────
    # 실패하면 스크래핑 자체를 건너뛴다. 로컬 state.json으로 폴백하면 "판단
    # 불가" 상태가 조용히 "변경 없음"으로 둔갑하는 예전 사고가 재발할 수 있다.
    known_versions = fetch_known_versions(config)
    if known_versions is None:
        err_msg = "xts_tool_versions 조회 실패 — DB 연결 불가로 추정. observer.log/PostgreSQL 상태 확인 필요."
        log_err(err_msg)
        notify_desktop("🛑 Tool Observer DB 조회 실패", err_msg)
        if not dry_run and config:
            try:
                send_email(config, [], db_error=err_msg)
            except Exception:
                pass  # send_email 내부에서 이미 notify_desktop으로 알렸음
        log("DB 조회 실패로 스크래핑 건너뜀 — 실행 종료")
        return

    changes_report: list[dict] = []
    new_state = dict(state)  # 실행하지 않은 대상의 이전 상태 유지

    async with async_playwright() as pw:
        if not PROFILE_DIR.exists():
            log_warn(f"브라우저 프로필 없음 ({PROFILE_DIR}) — python setup_auth.py를 먼저 실행하세요")
        # 비정상 종료 또는 다른 머신에서 복사 시 잔여 락 파일 제거
        singleton_lock = PROFILE_DIR / "SingletonLock"
        if singleton_lock.exists() or singleton_lock.is_symlink():
            singleton_lock.unlink()
        context: BrowserContext = await pw.chromium.launch_persistent_context(
            str(PROFILE_DIR),
            headless=True,
            args=[
                "--no-sandbox",
                "--disable-dev-shm-usage",
            ],
            viewport={"width": 1280, "height": 900},
        )
        log(f"브라우저 프로필 로드: {PROFILE_DIR}")

        page: Page = await context.new_page()

        # ── 세션 사전 확인 ────────────────────────────────────────────────────
        auth_failed_early: list[str] = []
        auth_failed_late: list[str] = []
        auth_targets = [t for t in targets if t.get("auth_required", False)]
        if auth_targets:
            log("세션 유효성 사전 확인 중...")
            try:
                await page.goto(auth_targets[0]["url"], wait_until="load", timeout=30000)
                if "accounts.google.com" in page.url or "signin" in page.url.lower():
                    log_warn("⚠️ 세션 만료 감지 — auth_required 대상 건너뜀")
                    auth_failed_early = [t["name"] for t in auth_targets]
                else:
                    log("세션 유효 확인")
            except Exception as e:
                log_warn(f"세션 사전 확인 실패: {e}")
        # ─────────────────────────────────────────────────────────────────────

        for target in targets:
            tid = target["id"]
            log(f"\n{'─'*50}")
            log(f"[{tid.upper()}] {target['name']}")

            extractor = EXTRACTORS.get(tid)
            if not extractor:
                log_warn(f"  등록된 추출 함수 없음: {tid}")
                continue

            # 세션 사전 확인에서 만료 감지된 경우 건너뜀
            if target.get("auth_required") and auth_failed_early:
                log(f"  세션 만료로 건너뜀")
                continue

            try:
                curr = await extractor(page, target)
                curr["checked_at"] = datetime.now(timezone.utc).isoformat()

                if is_auth_failed(curr, target):
                    log_warn(f"  ⚠️ 인증 실패 의심 (값 전부 미발견) — 이전 상태 유지, 비교 생략")
                    auth_failed_late.append(target["name"])
                    continue

                known = known_versions.get(SUITE_NAME_MAP.get(tid, ""), set())
                changes = detect_changes(tid, known, curr, force=test_email)
                new_state[tid] = curr

                if changes:
                    log(f"  ✅ 변경 {len(changes)}건 감지")
                    for c in changes:
                        log(f"     {c}")
                    changes_report.append({
                        "name": target["name"],
                        "changes": changes,
                        "last_updated": curr.get("last_updated"),
                    })
                else:
                    log("  — 변경 없음")

            except Exception as e:
                log_err(f"  추출 실패: {e}")
                log_err(traceback.format_exc())

        await context.close()

    if not dry_run:
        save_state(new_state)
        log(f"\n{'='*60}")
        log("상태 저장 완료")
    else:
        log(f"\n{'='*60}")
        log("[dry-run] 상태 저장 생략")

    # auth 실패 판단: 사전 확인(URL 기반) + 도구별 사후 확인(추출값 전부 미발견) 병합
    # 사전 확인만으로는 "로그인 페이지로 리다이렉트되진 않지만 콘텐츠는 못 읽는" 반쯤
    # 죽은 세션을 못 잡기 때문에, 도구별 is_auth_failed() 결과도 함께 반영한다.
    auth_failed: list[str] = list(dict.fromkeys(auth_failed_early + auth_failed_late))

    if auth_failed:
        log_warn(f"세션 만료 의심 도구: {auth_failed}")

    if changes_report:
        total = sum(len(r["changes"]) for r in changes_report)
        log(f"변경사항 총 {total}건 감지")
    else:
        log("변경사항 없음")

    if dry_run:
        log("[dry-run] 이메일 미발송")
    elif not config:
        log_warn("config.yaml 없음 — 이메일 미발송")
    elif test_email:
        log("[test-email] 강제 발송")
        send_email(config, changes_report, new_state, targets_all)
    elif auth_failed:
        send_email(config, [], state, targets_all, auth_failed_tools=auth_failed)
    else:
        send_email(config, changes_report, new_state, targets_all)

    log("Tool Observer 완료")
    return changes_report


def main():
    parser = argparse.ArgumentParser(description="Tool Observer — XTS 도구 업데이트 감시")
    parser.add_argument(
        "--id",
        nargs="+",
        metavar="ID",
        help="실행할 대상 ID (예: --id cts gts). 생략 시 전체 실행.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="변경 감지만 수행, 이메일 미발송",
    )
    parser.add_argument(
        "--test-email",
        action="store_true",
        help="이전 상태 초기화 후 전체 버전을 신규 변경으로 처리해 이메일 발송 (레이아웃 확인용)",
    )
    args = parser.parse_args()
    asyncio.run(run(target_ids=args.id, dry_run=args.dry_run, test_email=args.test_email))


if __name__ == "__main__":
    main()

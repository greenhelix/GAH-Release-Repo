#!/bin/bash
# Tool Observer 신규 서버 환경 세팅
# 사용법: bash install.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=== Tool Observer 설치 ==="
echo ""

# Python 3.10+ 탐색 (3.12, 3.11, 3.10 순으로 시도)
PYTHON=""
for candidate in python3.12 python3.11 python3.10 python3; do
    if command -v "$candidate" &>/dev/null; then
        VER=$("$candidate" -c 'import sys; print(sys.version_info[:2])')
        # (3, 10) 이상인지 확인
        if "$candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)' 2>/dev/null; then
            PYTHON="$candidate"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    echo "[오류] Python 3.10 이상을 찾을 수 없습니다."
    echo ""
    echo "Ubuntu 20.04/22.04 기준 설치 방법:"
    echo "  sudo apt update"
    echo "  sudo apt install -y python3.10 python3.10-venv"
    echo ""
    echo "설치 후 다시 실행하세요: bash install.sh"
    exit 1
fi

echo "[1/4] Python: $($PYTHON --version)"

# venv 생성
if [ ! -d "venv" ]; then
    echo "[2/4] venv 생성 중..."
    $PYTHON -m venv venv
else
    echo "[2/4] venv 이미 존재, 건너뜀"
fi

# 반드시 venv 안의 pip 사용
PIP="$SCRIPT_DIR/venv/bin/pip"
PYTHON_VENV="$SCRIPT_DIR/venv/bin/python"

# pip 의존성 설치
echo "[3/4] pip 의존성 설치 중..."
$PIP install --quiet --upgrade pip
$PIP install --quiet -r requirements.txt

# Playwright 브라우저 바이너리 설치
echo "[4/4] Playwright Chromium 설치 중..."
"$SCRIPT_DIR/venv/bin/playwright" install chromium
"$SCRIPT_DIR/venv/bin/playwright" install-deps chromium

echo ""
echo "=== 설치 완료 ==="
echo ""
echo "다음 단계:"
echo "  1. config.yaml 설정   : cp config.yaml.example config.yaml && vi config.yaml"
echo "  2. credentials.json   : Google Cloud Console OAuth2 클라이언트 파일 배치"
echo "  3. 파트너 포털 로그인  : venv/bin/python setup_auth.py"
echo "  4. Gmail API 인증     : venv/bin/python cli.py test-email"
echo "  5. cron 등록          : crontab -e"
echo ""
echo "자세한 내용: SETUP.md"

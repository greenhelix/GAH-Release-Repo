#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""
선택적 Claude 진단 — 있으면 좋은 부가 기능일 뿐, 코어 파이프라인(스크래핑 →
DB 저장 → 이메일)은 이 모듈의 성공/실패와 완전히 무관하게 동작한다.

구 agent_runner.py Phase 2는 멀티턴 tool-use 루프로 로그 텍스트를 읽고
success/auth_failed/... 상태를 "추측"했고, 그 판단이 실행 성공 여부와
DB 저장까지 좌우했다 (ANTHROPIC_API_KEY 없으면 전체가 멈추는 사고의 원인).
이제 상태 판정은 core/classify.py + cli.py가 결정적으로 끝내고, 여기는
이미 계산된 RunResult를 재료로 짧은 진단 텍스트 하나만 받아온다.
targets.yaml을 수정하거나 이메일을 보내는 등의 부작용은 일으키지 않는다.
"""

from core.log import log, log_warn
from core.secrets import resolve_anthropic_key
from core.types import RunResult

MODEL = "claude-haiku-4-5-20251001"
MAX_LOG_CHARS = 4000


def enrich(run_result: RunResult, config: dict, log_tail: str = "") -> str | None:
    """실패해도(키 없음/타임아웃/API 오류) 예외를 던지지 않고 None만 반환한다."""
    api_key = resolve_anthropic_key(config)
    if not api_key:
        log("ANTHROPIC_API_KEY 없음 — Claude 진단 생략 (핵심 파이프라인엔 영향 없음)")
        return None

    try:
        import anthropic
    except ImportError:
        return None

    prompt = f"""아래는 GAH Tool Observer(Android XTS 도구 버전 감시 스크레이퍼) 실행 결과입니다.
한두 문장으로 사람이 다음에 뭘 해야 할지 간단히 진단해주세요. 이미 결정된 status/exit_code를
바꾸려 하지 말고, 참고용 진단 텍스트만 작성하세요.

실행 결과: {run_result.to_dict()}

로그 일부:
{log_tail[-MAX_LOG_CHARS:]}"""

    try:
        client = anthropic.Anthropic(api_key=api_key)
        response = client.messages.create(
            model=MODEL,
            max_tokens=300,
            messages=[{"role": "user", "content": prompt}],
        )
        text_blocks = [b.text for b in response.content if getattr(b, "type", None) == "text"]
        diagnosis = "\n".join(text_blocks).strip()
        return diagnosis or None
    except Exception as e:
        log_warn(f"Claude 진단 실패 (무시 가능, 핵심 파이프라인엔 영향 없음): {e}")
        return None

#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""
시크릿 해석 — 환경변수가 있으면 그걸 쓰고, 없으면 config.yaml 값으로 폴백.

기존엔 DB_*는 agent_runner.py가 os.environ만, tool_observer.py는 config.yaml의
db: 섹션만 읽어서 같은 DB를 가리키는 게 우연이었다. ANTHROPIC_API_KEY는
config.yaml에 claude.api_key로 이미 존재하는데 아무 코드도 안 읽고 있었다.
이 모듈이 두 값 다 하나의 규칙(env 우선, config 폴백)으로 통일한다.
"""

import os


def resolve_db_config(config: dict) -> dict:
    """DB 접속 정보. DB_* 환경변수가 있으면 우선, 없으면 config.yaml의 db: 섹션,
    그것도 없으면 마지막 기본값."""
    db_cfg = dict(config.get("db") or {})
    env_map = {
        "host": "DB_HOST",
        "port": "DB_PORT",
        "dbname": "DB_NAME",
        "user": "DB_USER",
        "password": "DB_PASSWORD",
    }
    for key, env_name in env_map.items():
        env_val = os.environ.get(env_name)
        if env_val:
            db_cfg[key] = env_val

    db_cfg.setdefault("host", "localhost")
    db_cfg.setdefault("port", "5432")
    db_cfg.setdefault("dbname", "gah")
    db_cfg.setdefault("user", "gah_user")
    db_cfg.setdefault("password", "")
    return db_cfg


def resolve_anthropic_key(config: dict) -> str | None:
    """ANTHROPIC_API_KEY 환경변수 우선, 없으면 config.yaml의 claude.api_key 폴백."""
    env_val = os.environ.get("ANTHROPIC_API_KEY")
    if env_val:
        return env_val
    return (config.get("claude") or {}).get("api_key") or None

#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""
추출 결과 판정 — 구 tool_observer.py의 is_auth_failed()를 일반화.

파이프라인(cli.py)이 각 도구 추출 직후 무조건 호출하는 구조라 다시 dead
code가 될 수 없다 (2026-08-04 사고: is_auth_failed()가 정의만 되고 호출부가
없어서 STS 무변경 오탐지가 발생했었음).

기존 is_auth_failed()는 auth_required 대상에만 적용됐다 — CTS(공개 페이지)가
구조 변경으로 깨져도 못 잡는 구멍이 있었음. 이 함수는 auth_required 여부와
무관하게 "값이 전부 비었는지"를 판정해 EXTRACTION_FAILED로 잡는다.
"""

from typing import Any

from .types import ToolOutcome


def classify_outcome(values: dict[str, Any], auth_required: bool) -> ToolOutcome:
    if not values:
        return ToolOutcome.AUTH_FAILED if auth_required else ToolOutcome.EXTRACTION_FAILED

    all_empty = True
    for v in values.values():
        if isinstance(v, dict):
            if any(val is not None for val in v.values()):
                all_empty = False
                break
        elif v is not None:
            all_empty = False
            break

    if not all_empty:
        return ToolOutcome.OK

    return ToolOutcome.AUTH_FAILED if auth_required else ToolOutcome.EXTRACTION_FAILED

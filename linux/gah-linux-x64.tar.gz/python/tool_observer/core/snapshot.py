#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""
디버그 스냅샷 — 구 state.json의 후신. 사람/AI가 마지막 스크래핑 원시값을
들여다볼 때만 쓰는 파일이며, 파이프라인의 어떤 판단(diff/알림)도 이 파일을
다시 읽지 않는다. 파일이 깨지거나 사라져도 실행 결과에 영향 없음.
"""

import json
from pathlib import Path

BASE_DIR = Path(__file__).parent.parent
SNAPSHOT_FILE = BASE_DIR / "debug" / "last_scrape.json"


def write(snapshot: dict) -> None:
    SNAPSHOT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(SNAPSHOT_FILE, "w", encoding="utf-8") as f:
        json.dump(snapshot, f, ensure_ascii=False, indent=2, default=str)


def read() -> dict:
    """디버깅/이메일의 '전체 현황' 표시용으로만 사용 — diff 판단에 쓰지 말 것."""
    if SNAPSHOT_FILE.exists():
        with open(SNAPSHOT_FILE, encoding="utf-8") as f:
            return json.load(f)
    return {}

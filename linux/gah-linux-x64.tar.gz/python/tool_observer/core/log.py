#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""로거 + 데스크톱 알림. tool_observer.py에서 거의 그대로 이동."""

import os
import subprocess
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).parent.parent
LOG_FILE = BASE_DIR / "observer.log"


def log(msg: str, level: str = "INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] [{level}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def log_warn(msg: str):
    log(msg, "WARN")


def log_err(msg: str):
    log(msg, "ERROR")


def notify_desktop(title: str, message: str, urgency: str = "critical"):
    """Gmail 알림 자체가 실패했을 때의 최후 수단 — Google 인증에 의존하지 않는
    로컬 데스크톱 알림. 이메일 발송 실패는 이 경로로만 사람에게 닿는다."""
    uid = os.getuid()
    env = os.environ.copy()
    env.setdefault("DISPLAY", ":0")
    env.setdefault("XAUTHORITY", f"/run/user/{uid}/gdm/Xauthority")
    env.setdefault("DBUS_SESSION_BUS_ADDRESS", f"unix:path=/run/user/{uid}/bus")
    try:
        subprocess.run(
            ["notify-send", "-u", urgency, "--expire-time=0", title, message],
            env=env, timeout=10, check=False,
        )
    except Exception as e:
        log_err(f"데스크톱 알림도 실패: {e}")

#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""여러 tools/<id>.py 추출기가 공유하는 작은 유틸. tool_observer.py에서 이동."""

import re

from playwright.async_api import Page


def extract_last_updated(text: str) -> str | None:
    """'Last updated YYYY-MM-DD UTC' 형식 추출"""
    m = re.search(r"Last updated (\d{4}-\d{2}-\d{2}) UTC", text)
    return m.group(1) if m else None


def platform_includes(platform_text: str, android_ver: int) -> bool:
    """
    'Android X - Y' 또는 'Android X' 범위에 android_ver 포함 여부 반환.
    예: 'Android 13 - 16' → ver=14 → True
    """
    range_m = re.search(r"Android\s+(\d+)\s*[-–]\s*(\d+)", platform_text)
    if range_m:
        lo, hi = int(range_m.group(1)), int(range_m.group(2))
        return lo <= android_ver <= hi
    single_m = re.search(r"Android\s+(\d+)", platform_text)
    if single_m:
        return int(single_m.group(1)) == android_ver
    return False


async def get_page_text(page: Page) -> str:
    """JS 렌더링 완료 후 innerText 전체 반환"""
    return await page.evaluate("() => document.body.innerText")

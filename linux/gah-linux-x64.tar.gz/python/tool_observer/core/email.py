#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""
이메일 빌드/발송 — tool_observer.py에서 거의 그대로 이동.

format_version/format_label은 도구별 파일(tools/<id>.py)로 억지로 쪼개지
않고 공용 유틸로 유지한다. 모르는 형식이면 raw 문자열을 그대로 보여주는
폴백이 이미 있어서, 굳이 쪼개는 실익보다 여기 모아두는 게 더 단순하다.
"""

import base64
import re
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

from . import db
from .log import log, log_err

BASE_DIR = Path(__file__).parent.parent
GMAIL_CREDENTIALS = BASE_DIR / "credentials.json"
GMAIL_TOKEN = BASE_DIR / "auth" / "gmail_token.json"
GMAIL_SCOPES = ["https://www.googleapis.com/auth/gmail.send"]

MONTH_MAP: dict[str, str] = {
    "January": "01", "February": "02", "March": "03", "April": "04",
    "May": "05", "June": "06", "July": "07", "August": "08",
    "September": "09", "October": "10", "November": "11", "December": "12",
}


# ── 버전 표시 포맷 ────────────────────────────────────────────────────────────

def format_version(raw: str) -> str:
    """원시 버전 문자열을 간결한 표시형으로 변환"""
    if not raw or raw in ("—", "None", "none"):
        return "—"
    m = re.match(r"android-cts-(\d+)\.\d+_r(\d+)", raw)
    if m:
        return f"CTS {m.group(1)} R{m.group(2)}"
    m = re.match(r"VTS-(\d+)_r(\d+)_arm", raw, re.IGNORECASE)
    if m:
        return f"VTS {m.group(1)} R{m.group(2)}"
    m = re.match(r"GTS_(\d+)(?:\.(\d+))?_r(\d+)", raw)
    if m:
        series = m.group(1) + (f".{m.group(2)}" if m.group(2) else "")
        return f"GTS {series} R{m.group(3)}"
    m = re.match(r"android-sts-(\d+)_sts-r(\d+)-", raw)
    if m:
        return f"STS {m.group(1)} R{m.group(2)}"
    m = re.match(r"Build\s+(\d+)\s*\(released on (\w+)\s+(\d+),\s+(\d{4})\)", raw)
    if m:
        mo = MONTH_MAP.get(m.group(2), "??")
        return f"{m.group(1)} ({m.group(4)[2:]}-{mo}-{m.group(3).zfill(2)})"
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})$", raw.strip())
    if m:
        return f"SPL: {m.group(1)[2:]}-{m.group(2)}-{m.group(3)}"
    return raw


def format_label(label: str) -> str:
    """변경 라벨을 표시용으로 변환 (간결하게)"""
    label = label.strip().replace("📅 ", "")
    m = re.match(r"Android\s+(\d+)\s*\[build\]", label)
    if m:
        return f"Android {m.group(1)} Build"
    m = re.match(r"Android\s+(\d+)\s*\[security_patch\]", label)
    if m:
        return f"Android {m.group(1)} SPL"
    m = re.match(r"Android\s+(\d+)\s*\[file\]", label)
    if m:
        return f"Android {m.group(1)} 파일"
    m = re.match(r"Android\s+(\d+)\s*\[date_modified\]", label)
    if m:
        return f"Android {m.group(1)} 갱신일"
    m = re.match(r"Android\s+(\d+)$", label)
    if m:
        return f"Android {m.group(1)}"
    if "Latest" in label:
        return "Latest"
    return label


def _fmt_last_updated(raw: str | None) -> str:
    """'2026-04-09' → '26-04-09', None → '—'"""
    if not raw:
        return "—"
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", raw)
    if m:
        return f"{m.group(1)[2:]}-{m.group(2)}-{m.group(3)}"
    return raw


def _parse_change_row(chg: str) -> tuple[str, str, str]:
    """변경 문자열을 (포맷된 라벨, 포맷된 이전값, 포맷된 이후값)으로 파싱"""
    if " → " in chg:
        label, rest = chg.split(": ", 1) if ": " in chg else ("", chg)
        old, new = rest.split(" → ", 1)
        return format_label(label), format_version(old.strip()), format_version(new.strip())
    return chg, "", ""


def _build_schedule_html(schedule: list[dict]) -> str:
    """분기별 일정 HTML 테이블"""
    if not schedule:
        return ""

    today = datetime.now().date()
    rows = ""
    for s in schedule:
        req_date = s["required_use_date"]
        is_upcoming = req_date and req_date >= today
        row_bg = "#FFF8E1" if is_upcoming else "#fafafa"
        badge = (
            '<span style="background:#F57F17;color:#fff;font-size:10px;'
            'padding:2px 6px;border-radius:8px;margin-left:6px">예정</span>'
            if is_upcoming else ""
        )
        rows += f"""
        <tr style="background:{row_bg}">
          <td style="padding:8px 12px;font-size:13px;font-weight:600;white-space:nowrap">
            {s['year']} Q{s['quarter']}{badge}
          </td>
          <td style="padding:8px 12px;font-size:12px;color:#555;white-space:nowrap">{s['announce_date'] or '—'}</td>
          <td style="padding:8px 12px;font-size:12px;color:#B71C1C;font-weight:bold;white-space:nowrap">{s['required_use_date'] or '—'}</td>
          <td style="padding:8px 12px;font-size:12px;font-family:monospace;color:#1565C0">{s['cts_next'] or '—'}</td>
          <td style="padding:8px 12px;font-size:12px;font-family:monospace;color:#2E7D32">{s['vts_next'] or '—'}</td>
          <td style="padding:8px 12px;font-size:12px;font-family:monospace;color:#6A1B9A">{s['gts_next'] or '—'}</td>
          <td style="padding:8px 12px;font-size:12px;color:#777">{s['notes'] or ''}</td>
        </tr>"""

    th = 'style="padding:6px 12px;text-align:left;font-size:11px;color:#666;font-weight:600;border-bottom:2px solid #e0e0e0;background:#f5f5f5"'
    return f"""
    <div style="margin-top:24px">
      <div style="font-size:14px;font-weight:700;color:#333;margin-bottom:10px;
                  padding-bottom:6px;border-bottom:2px solid #F57F17">분기별 업데이트 일정</div>
      <div style="background:#fff;border-radius:8px;border:1px solid #e0e0e0;overflow:hidden">
        <table width="100%" cellpadding="0" cellspacing="0">
          <tr>
            <th {th}>분기</th>
            <th {th}>공지일</th>
            <th {th}>필수 적용일</th>
            <th {th}>CTS</th>
            <th {th}>VTS</th>
            <th {th}>GTS</th>
            <th {th}>비고</th>
          </tr>
          {rows}
        </table>
      </div>
    </div>"""


def build_email_html(changes_report: list[dict], state: dict | None = None,
                     targets_all: list[dict] | None = None,
                     config: dict | None = None) -> str:
    """변경 감지 이메일 — 전체 현황 테이블 + 변경 카드"""
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    total = sum(len(r["changes"]) for r in changes_report)

    status_table = (
        _build_status_table_html(state, targets_all)
        if state is not None and targets_all is not None else ""
    )
    status_section = (
        f'<div style="margin-bottom:28px">'
        f'<div style="font-size:14px;font-weight:700;color:#333;margin-bottom:10px'
        f';padding-bottom:6px;border-bottom:2px solid #1565C0">전체 현황</div>'
        f'{status_table}</div>'
    ) if status_table else ""

    cards_html = ""
    for item in changes_report:
        lu = _fmt_last_updated(item.get("last_updated"))
        lu_badge = (
            f'<span style="color:#90CAF9;font-size:12px;margin-left:10px">'
            f'갱신: {lu}</span>'
        ) if lu != "—" else ""

        rows = ""
        for chg in item["changes"]:
            label, old, new = _parse_change_row(chg)
            if old == "—":
                old_cell = '<span style="background:#FFF3E0;color:#E65100;font-size:11px;padding:2px 6px;border-radius:3px;font-family:sans-serif">신규</span>'
            else:
                old_cell = f'<span style="color:#aaa;font-family:monospace;text-decoration:line-through">{old}</span>'
            rows += f"""
            <tr>
              <td style="padding:9px 14px;color:#555;font-size:13px;border-bottom:1px solid #f0f0f0;width:140px;font-weight:500">{label}</td>
              <td style="padding:9px 12px;font-size:13px;border-bottom:1px solid #f0f0f0">{old_cell}</td>
              <td style="padding:9px 8px;color:#bbb;font-size:16px;border-bottom:1px solid #f0f0f0;font-weight:bold">→</td>
              <td style="padding:9px 14px;color:#1B5E20;font-size:13px;border-bottom:1px solid #f0f0f0;font-family:monospace;font-weight:bold">{new}</td>
            </tr>"""

        cards_html += f"""
        <div style="background:#fff;border-radius:8px;border:1px solid #e0e0e0;margin-bottom:14px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.06)">
          <div style="background:#1565C0;padding:10px 16px;display:flex;align-items:center">
            <span style="color:#fff;font-weight:bold;font-size:15px">{item['name']}</span>
            {lu_badge}
            <span style="background:#0D47A1;color:#BBDEFB;font-size:12px;padding:2px 8px;border-radius:10px;margin-left:auto">{len(item['changes'])}건 변경</span>
          </div>
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr style="background:#f8f9fa">
              <th style="padding:6px 14px;text-align:left;font-size:11px;color:#999;font-weight:600;width:140px;letter-spacing:0.5px">항목</th>
              <th style="padding:6px 12px;text-align:left;font-size:11px;color:#999;font-weight:600">이전</th>
              <th style="width:28px"></th>
              <th style="padding:6px 14px;text-align:left;font-size:11px;color:#999;font-weight:600">현재</th>
            </tr>
            {rows}
          </table>
        </div>"""

    changes_section = (
        f'<div style="margin-top:8px">'
        f'<div style="font-size:14px;font-weight:700;color:#333;margin-bottom:10px'
        f';padding-bottom:6px;border-bottom:2px solid #E53935">변경 내역</div>'
        f'{cards_html}</div>'
    )

    schedule = db.fetch_quarterly_schedule(config) if config else []
    schedule_section = _build_schedule_html(schedule)

    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0;background:#f0f2f5">
  <div style="max-width:740px;margin:24px auto;padding:0 16px">

    <div style="background:linear-gradient(135deg,#1565C0,#0D47A1);border-radius:10px 10px 0 0;padding:22px 28px">
      <div style="color:#fff;font-size:20px;font-weight:bold;letter-spacing:-0.3px">XTS 도구 업데이트 감지</div>
      <div style="color:#90CAF9;font-size:13px;margin-top:5px">검사 일시: {today}</div>
    </div>

    <div style="background:#E53935;padding:11px 24px">
      <span style="color:#fff;font-weight:bold;font-size:14px">⚡ 총 {total}건의 변경사항이 감지되었습니다.</span>
    </div>

    <div style="background:#fff;border-radius:0 0 10px 10px;padding:24px 24px 20px;border:1px solid #e0e0e0;border-top:none">
      {status_section}
      {changes_section}
      {schedule_section}
    </div>

    <div style="text-align:center;padding:14px;color:#aaa;font-size:11px">
      GAH Tool Observer — 자동 발송 메일입니다.
    </div>
  </div>
</body>
</html>"""


def _gsi_cell(ver_dict: dict | None) -> str:
    """GSI 버전 딕셔너리를 한 셀 텍스트로 변환"""
    if not ver_dict:
        return "—"
    build_str = format_version(ver_dict.get("build") or "")
    spl_raw = ver_dict.get("security_patch")
    spl = format_version(spl_raw) if spl_raw else ""
    parts = []
    if build_str and build_str != "—":
        parts.append(build_str)
    if spl and spl != "—":
        parts.append(spl)
    return "<br>".join(parts) if parts else "—"


def _build_status_table_html(state: dict, targets_all: list[dict]) -> str:
    """전 도구 버전 현황 매트릭스 테이블 HTML.
    state는 core/snapshot.py가 관리하는 '이번 실행 기준 최신 스냅샷'이며,
    diff 판단에는 관여하지 않는 표시 전용 데이터다."""
    th = (
        '<th style="padding:8px 12px;text-align:left;font-size:12px;'
        'color:#555;font-weight:600;border-bottom:2px solid #e0e0e0">'
    )
    header = (
        f"{th}도구</th>"
        f"{th}Android 12</th>"
        f"{th}Android 14</th>"
        f"{th}Android 16</th>"
        f"{th}last update</th>"
    )

    rows = ""
    for i, target in enumerate(targets_all):
        tid = target["id"]
        curr = state.get(tid, {})
        versions = curr.get("versions", {})
        lu = _fmt_last_updated(curr.get("last_updated"))
        bg = "#ffffff" if i % 2 == 0 else "#f9f9f9"

        td_base = (
            f'style="padding:9px 12px;font-size:13px;border-bottom:1px solid #f0f0f0;'
            f'vertical-align:top;background:{bg}"'
        )
        td_mono = (
            f'style="padding:9px 12px;font-size:12px;font-family:monospace;'
            f'color:#2E7D32;border-bottom:1px solid #f0f0f0;vertical-align:top;background:{bg}"'
        )
        td_none = (
            f'style="padding:9px 12px;font-size:12px;font-family:monospace;'
            f'color:#bbb;border-bottom:1px solid #f0f0f0;vertical-align:top;background:{bg}"'
        )
        td_date = (
            f'style="padding:9px 12px;font-size:12px;color:#888;'
            f'border-bottom:1px solid #f0f0f0;vertical-align:top;background:{bg};white-space:nowrap"'
        )

        def ver_cell(key: str) -> str:
            val = versions.get(key)
            if val is None:
                return f'<td {td_none}>업데이트 안됨</td>'
            if isinstance(val, dict):
                if "file" in val:
                    fv = format_version(str(val.get("file") or ""))
                    dm = val.get("date_modified") or ""
                    if fv and fv != "—":
                        dm_html = (
                            f'<br><span style="color:#888;font-size:11px;font-family:sans-serif">{dm}</span>'
                            if dm else ""
                        )
                        return f'<td {td_mono}>{fv}{dm_html}</td>'
                    return f'<td {td_none}>업데이트 안됨</td>'
                cell = _gsi_cell(val)
                return f'<td {td_mono}>{cell}</td>' if cell != "—" else f'<td {td_none}>업데이트 안됨</td>'
            fv = format_version(str(val))
            return f'<td {td_mono}>{fv}</td>'

        if "Latest Version" in versions:
            latest = format_version(str(versions.get("Latest Version") or "—"))
            val_html = latest if latest != "—" else '<span style="color:#bbb">업데이트 안됨</span>'
            rows += (
                f'<tr>'
                f'<td {td_base}><b>{target["name"]}</b></td>'
                f'<td colspan="3" style="padding:9px 12px;font-size:12px;'
                f'font-family:monospace;color:#2E7D32;border-bottom:1px solid #f0f0f0;'
                f'vertical-align:top;background:{bg}">'
                f'<span style="font-size:10px;color:#888;font-family:sans-serif;'
                f'margin-right:6px;font-weight:normal">전 버전 공통</span>{val_html}</td>'
                f'<td {td_date}>{lu}</td>'
                f'</tr>'
            )
        else:
            rows += (
                f'<tr>'
                f'<td {td_base}><b>{target["name"]}</b></td>'
                f'{ver_cell("12")}{ver_cell("14")}{ver_cell("16")}'
                f'<td {td_date}>{lu}</td>'
                f'</tr>'
            )

    return f"""
    <div style="background:#fff;border-radius:8px;border:1px solid #e0e0e0;overflow:hidden">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr style="background:#f0f4f8">{header}</tr>
        {rows}
      </table>
    </div>"""


def build_no_change_email(state: dict, targets_all: list[dict], config: dict | None = None) -> str:
    """변경 없음 — 전 도구 버전 현황 매트릭스"""
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    table_html = _build_status_table_html(state, targets_all)
    schedule = db.fetch_quarterly_schedule(config) if config else []
    schedule_section = _build_schedule_html(schedule)

    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0;background:#f0f2f5">
  <div style="max-width:740px;margin:24px auto;padding:0 16px">

    <div style="background:linear-gradient(135deg,#2E7D32,#1B5E20);border-radius:10px 10px 0 0;padding:22px 28px">
      <div style="color:#fff;font-size:20px;font-weight:bold;letter-spacing:-0.3px">XTS 도구 상태 점검</div>
      <div style="color:#A5D6A7;font-size:13px;margin-top:5px">검사 일시: {today}</div>
    </div>

    <div style="background:#2E7D32;padding:11px 24px">
      <span style="color:#fff;font-weight:bold;font-size:14px">✅ 변경 없음 — 모든 도구가 최신 상태입니다.</span>
    </div>

    <div style="background:#fff;border-radius:0 0 10px 10px;padding:24px;border:1px solid #e0e0e0;border-top:none">
      <div style="font-size:14px;font-weight:700;color:#333;margin-bottom:10px;padding-bottom:6px;border-bottom:2px solid #2E7D32">전체 현황</div>
      {table_html}
      {schedule_section}
    </div>

    <div style="text-align:center;padding:14px;color:#aaa;font-size:11px">
      GAH Tool Observer — 자동 발송 메일입니다.
    </div>
  </div>
</body>
</html>"""


def build_auth_alert_email(failed_tools: list[str], config: dict | None = None) -> str:
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    tool_list = "".join(f"<li>{t}</li>" for t in failed_tools)
    schedule = db.fetch_quarterly_schedule(config) if config else []
    schedule_section = _build_schedule_html(schedule)
    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0;background:#f5f5f5">
  <div style="max-width:680px;margin:24px auto;padding:0 16px">
    <div style="background:#B71C1C;border-radius:10px 10px 0 0;padding:20px 24px">
      <div style="color:#fff;font-size:20px;font-weight:bold">⚠️ 세션 만료 — 재인증 필요</div>
      <div style="color:#EF9A9A;font-size:13px;margin-top:4px">감지 일시: {today}</div>
    </div>
    <div style="background:#fff;border-radius:0 0 8px 8px;border:1px solid #e0e0e0;padding:20px 24px">
      <p style="color:#333;font-size:14px">아래 도구의 데이터를 가져오지 못했습니다. Google 로그인 세션이 만료된 것으로 보입니다.</p>
      <ul style="color:#B71C1C;font-size:14px">{tool_list}</ul>
      {schedule_section}
    </div>
    <div style="text-align:center;padding:16px;color:#aaa;font-size:11px">GAH Tool Observer — 자동 발송 메일입니다.</div>
  </div>
</body>
</html>"""


def build_db_error_email(error_msg: str) -> str:
    """xts_tool_versions 조회 자체가 실패했을 때 — diff 기준을 세울 수 없어
    스크래핑을 아예 건너뛰었다는 뜻. '변경 없음'과 절대 혼동되면 안 되는 상태."""
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:0;background:#f5f5f5">
  <div style="max-width:680px;margin:24px auto;padding:0 16px">
    <div style="background:#B71C1C;border-radius:10px 10px 0 0;padding:20px 24px">
      <div style="color:#fff;font-size:20px;font-weight:bold">🛑 DB 조회 실패 — 실행 중단</div>
      <div style="color:#EF9A9A;font-size:13px;margin-top:4px">감지 일시: {today}</div>
    </div>
    <div style="background:#fff;border-radius:0 0 8px 8px;border:1px solid #e0e0e0;padding:20px 24px">
      <p style="color:#333;font-size:14px">
        xts_tool_versions 조회에 실패해 어떤 버전이 신규인지 판단할 기준이 없습니다.
        오탐지를 막기 위해 스크래핑을 건너뛰었습니다 — 실제로는 변경이 있었을 수 있습니다.
      </p>
      <pre style="background:#fafafa;border:1px solid #eee;border-radius:6px;padding:12px;
                  color:#B71C1C;font-size:12px;white-space:pre-wrap">{error_msg}</pre>
      <p style="color:#333;font-size:14px">PostgreSQL 서비스 상태를 확인하세요: <code>sudo systemctl status postgresql</code></p>
    </div>
    <div style="text-align:center;padding:16px;color:#aaa;font-size:11px">GAH Tool Observer — 자동 발송 메일입니다.</div>
  </div>
</body>
</html>"""


def _get_gmail_service():
    """Gmail API 서비스 객체 반환 (최초 실행 시 OAuth2 인증 브라우저 열림)"""
    creds = None
    if GMAIL_TOKEN.exists():
        creds = Credentials.from_authorized_user_file(str(GMAIL_TOKEN), GMAIL_SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                str(GMAIL_CREDENTIALS), GMAIL_SCOPES
            )
            creds = flow.run_local_server(port=0)
        GMAIL_TOKEN.parent.mkdir(parents=True, exist_ok=True)
        GMAIL_TOKEN.write_text(creds.to_json())
    return build("gmail", "v1", credentials=creds)


def send_email(config: dict, changes_report: list[dict],
               state: dict | None = None, targets_all: list[dict] | None = None,
               auth_failed_tools: list[str] | None = None,
               db_error: str | None = None) -> None:
    smtp_cfg = config["smtp"]
    today = datetime.now().strftime("%Y-%m-%d")

    if db_error:
        subject = f"[GAH] 🛑 Tool Observer DB 조회 실패 {today}"
        html = build_db_error_email(db_error)
    elif auth_failed_tools:
        subject = f"[GAH] ⚠️ 세션 만료 — 재인증 필요 {today}"
        html = build_auth_alert_email(auth_failed_tools, config)
    elif bool(changes_report):
        total = sum(len(r["changes"]) for r in changes_report)
        subject = f"[GAH] XTS 업데이트 감지 {total}건 — {today}"
        html = build_email_html(changes_report, state, targets_all, config)
    else:
        subject = f"[GAH] XTS 변경 없음 — {today}"
        html = build_no_change_email(state or {}, targets_all or [], config)

    if auth_failed_tools or db_error:
        recipients = smtp_cfg.get("alert_to") or smtp_cfg["to"]
    else:
        recipients = smtp_cfg["to"]

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = smtp_cfg["from"]
    msg["To"] = ", ".join(recipients)
    msg.attach(MIMEText(html, "html", "utf-8"))

    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    try:
        service = _get_gmail_service()
        service.users().messages().send(userId="me", body={"raw": raw}).execute()
        log(f"이메일 발송 완료 → {recipients}")
    except Exception as e:
        log_err(f"이메일 발송 실패 — Gmail 인증 문제로 추정: {e}")
        # 데스크톱 알림은 tool-observer-alert.service(zenity, OnFailure)가
        # exit_code=1로 단일 창 처리한다 — 여기서 또 notify_desktop을 쏘면 팝업이 중복됨
        raise

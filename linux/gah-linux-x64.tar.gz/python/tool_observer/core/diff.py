#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""
DB(xts_tool_versions) 기준 신규 버전 판단 — state.json 대신 여기가 유일한
"이미 본 버전인지" 판단 기준이다. 로컬 파일이 깨지거나 비어있어도 오탐지
("변경없음"으로 잘못 조용히 넘어가는 것)가 구조적으로 발생하지 않는다.
"""

from typing import Any


def decide_new_versions(
    normalize_version,
    values: dict[str, Any],
    known: dict[str, set[str]] | None,
    force: bool = False,
    release_dates: dict[str, str | None] | None = None,
) -> list[tuple[str, str, str | None, str | None]]:
    """values(추출 결과) 중 known(DB에 이미 있는 버전)에 없는 것만
    (android_key, version_str, notes, released_at) 튜플로 반환.

    known: {android_key → 이미 DB에 있는 version 집합}.
    None이거나 비어있으면(해당 suite가 DB에 아직 없음) 유효값 전부를 신규로 처리.
    force=True면 known과 무관하게 전부 신규로 처리 (test-email용).
    release_dates: ExtractionResult.release_dates — 대부분 suite는 비어있어 released_at=None."""
    known = known or {}
    release_dates = release_dates or {}
    new: list[tuple[str, str, str | None, str | None]] = []

    for key, raw_val in values.items():
        version_str, notes = normalize_version(key, raw_val)
        if version_str is None:
            continue  # 추출 실패/정규화 불가 — 신규도 무변경도 아님, 판단 보류
        android_known = known.get(key, set())
        if not force and version_str in android_known:
            continue
        new.append((key, version_str, notes, release_dates.get(key)))

    return new


def format_changes(new_versions: list[tuple[str, str, str | None, str | None]], raw_values: dict[str, Any]) -> list[str]:
    """decide_new_versions() 결과를 이메일 표시용 문자열로 변환.
    구 detect_changes()가 만들던 "Android X: None → Y" / "Android X [sub]: None → Y"
    형식과 동일 — email.py의 기존 파서(_parse_change_row)가 그대로 재사용 가능."""
    changes: list[str] = []
    for key, _version_str, _notes, _released_at in new_versions:
        curr_val = raw_values.get(key)
        if isinstance(curr_val, dict):
            for sub_key, sub_val in curr_val.items():
                if sub_val is not None:
                    changes.append(f"Android {key} [{sub_key}]: None → {sub_val}")
        else:
            changes.append(f"Android {key}: None → {curr_val}")
    return changes

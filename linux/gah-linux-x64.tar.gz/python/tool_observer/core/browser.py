#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""Playwright 브라우저 세션 관리. tool_observer.py에서 거의 그대로 이동."""

from pathlib import Path

from playwright.async_api import BrowserContext, Page, async_playwright

from .log import log, log_warn

BASE_DIR = Path(__file__).parent.parent
PROFILE_DIR = BASE_DIR / "auth" / "browser_profile"


async def launch_context(pw) -> BrowserContext:
    """setup_auth.py가 만든 영구 프로필로 headless 브라우저 컨텍스트 실행."""
    if not PROFILE_DIR.exists():
        log_warn(f"브라우저 프로필 없음 ({PROFILE_DIR}) — python setup_auth.py를 먼저 실행하세요")

    # 비정상 종료 또는 다른 머신에서 복사 시 잔여 락 파일 제거
    singleton_lock = PROFILE_DIR / "SingletonLock"
    if singleton_lock.exists() or singleton_lock.is_symlink():
        singleton_lock.unlink()

    context = await pw.chromium.launch_persistent_context(
        str(PROFILE_DIR),
        headless=True,
        args=["--no-sandbox", "--disable-dev-shm-usage"],
        viewport={"width": 1280, "height": 900},
    )
    log(f"브라우저 프로필 로드: {PROFILE_DIR}")
    return context


async def check_session(page: Page, auth_targets: list[dict]) -> list[str]:
    """auth_required 대상 중 첫 번째 URL이 로그인 페이지로 리다이렉트되는지만
    확인하는 저렴한 사전 체크. 통과해도 실제 콘텐츠 로딩은 보장 안 됨 —
    그건 각 tools/<id>.py의 extract() + core/classify.py가 사후에 잡는다.
    반환값: 세션이 죽은 것으로 판정된 대상들의 name 리스트."""
    if not auth_targets:
        return []

    log("세션 유효성 사전 확인 중...")
    try:
        await page.goto(auth_targets[0]["url"], wait_until="load", timeout=30000)
        if "accounts.google.com" in page.url or "signin" in page.url.lower():
            log_warn("⚠️ 세션 만료 감지 — auth_required 대상 건너뜀")
            return [t["name"] for t in auth_targets]
        log("세션 유효 확인")
        return []
    except Exception as e:
        log_warn(f"세션 사전 확인 실패: {e}")
        return []

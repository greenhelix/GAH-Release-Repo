#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""PostgreSQL 접근 — DB 조회/기록의 유일한 창구.

xts_tool_versions: 신규 버전 판단의 유일한 기준 (Phase 1에서 state.json 대체).
tool_observer_runs: 실행 이력. GAH 앱 '실행 이력' 탭이 읽는 테이블(Phase 6).
"""

import psycopg2

from .log import log_err, log_warn
from .secrets import resolve_db_config

# tool_observer_runs.status의 CHECK 제약(success/auth_failed/url_changed/
# network_error/unknown_error)은 기존 스키마 그대로 유지 — 마이그레이션 없이
# 새 RunResult.status(더 세분화된 값)를 이 허용값으로 매핑해서 저장한다.
_STATUS_DB_MAP = {
    "success": "success",
    "partial_auth_failed": "auth_failed",
    "partial_extraction_failed": "unknown_error",
    "db_unavailable": "network_error",
    "hard_error": "unknown_error",
}


def get_conn(config: dict):
    db = resolve_db_config(config)
    return psycopg2.connect(
        host=db["host"],
        port=int(db["port"]),
        dbname=db["dbname"],
        user=db["user"],
        password=db["password"],
    )


def read_known_versions(config: dict) -> dict[str, dict[str, set[str]]] | None:
    """xts_tool_versions에 이미 기록된 버전 조회.
    반환: {suite_name → {android_key → version 집합}}.
    None이면 DB 조회 자체가 실패한 것 — 빈 dict({})와 반드시 구분해서 다룰 것."""
    try:
        conn = get_conn(config)
        cur = conn.cursor()
        cur.execute("SELECT suite_name, android_key, version FROM xts_tool_versions")
        rows = cur.fetchall()
        cur.close()
        conn.close()
    except Exception as e:
        log_err(f"xts_tool_versions 조회 실패: {e}")
        return None

    known: dict[str, dict[str, set[str]]] = {}
    for suite_name, android_key, version in rows:
        ak = android_key or ""
        known.setdefault(suite_name, {}).setdefault(ak, set()).add(version)
    return known


def upsert_tool_versions(
    config: dict,
    rows: list[tuple[str, str, str, str | None, str | None, str | None]],
) -> bool:
    """(suite_name, android_key, version, notes, detected_at, released_at) 목록을
    xts_tool_versions에 upsert.
    ON CONFLICT(suite_name, android_key, version)이면:
      - notes는 기존값 유지 (처음 감지된 notes만 보존)
      - previous_version은 기존 version으로 갱신 (중복이면 동일하므로 변화 없음)
      - detected_at은 최신값으로 갱신
      - released_at은 스크래핑으로 읽은 값이 있으면 채움, 없으면 기존값(수동 입력 등) 유지
        — 사이트가 실제 릴리즈일을 제공하지 않는 suite는 released_at=None이라
          이 컬럼은 계속 비어있고(detected_at만 채워짐), GAH UI가 이를 구분 표시한다
    재시도해도 안전(idempotent)."""
    if not rows:
        return True
    try:
        conn = get_conn(config)
        cur = conn.cursor()
        for suite_name, android_key, version, notes, detected_at, released_at in rows:
            cur.execute(
                """
                INSERT INTO xts_tool_versions
                    (suite_name, android_key, android, version, notes, detected_at, released_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (suite_name, android_key, version)
                DO UPDATE SET
                    notes       = COALESCE(EXCLUDED.notes, xts_tool_versions.notes),
                    detected_at = COALESCE(EXCLUDED.detected_at, xts_tool_versions.detected_at),
                    released_at = COALESCE(EXCLUDED.released_at, xts_tool_versions.released_at)
                """,
                (suite_name, android_key, android_key, version, notes, detected_at, released_at),
            )
        conn.commit()
        cur.close()
        conn.close()
        return True
    except Exception as e:
        log_err(f"xts_tool_versions 저장 실패: {e}")
        return False


def insert_run_result(config: dict, run_result) -> str | None:
    """tool_observer_runs에 이번 실행 요약 1행 삽입. 삽입된 행의 id(uuid) 반환,
    실패 시 None. Claude 키 유무와 무관하게 항상 시도한다."""
    db_status = _STATUS_DB_MAP.get(run_result.status, "unknown_error")
    failed_tools = list(dict.fromkeys(run_result.auth_failed_tools + run_result.extraction_failed_tools))
    error_summary = None
    if run_result.status != "success":
        error_summary = f"status={run_result.status}"
        if run_result.db_write_error:
            error_summary += f" db_write_error={run_result.db_write_error}"
        if run_result.email_error:
            error_summary += f" email_error={run_result.email_error}"

    try:
        conn = get_conn(config)
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO tool_observer_runs
                (status, changes_count, failed_tools, error_summary,
                 observer_exit_code, run_duration_sec)
            VALUES (%s, %s, %s, %s, %s, %s)
            RETURNING id
            """,
            (
                db_status,
                run_result.total_new_versions,
                failed_tools or None,
                error_summary,
                run_result.exit_code,
                round(run_result.duration_sec, 2),
            ),
        )
        run_id = cur.fetchone()[0]
        conn.commit()
        cur.close()
        conn.close()
        return str(run_id)
    except Exception as e:
        log_err(f"tool_observer_runs 저장 실패: {e}")
        return None


def update_run_agent_action(config: dict, run_id: str, agent_action: str) -> bool:
    """선택적 Claude 진단 결과를 이미 삽입된 실행 행에 덧붙인다.
    이 함수가 실패해도 run_id로 삽입된 원래 행은 이미 커밋된 상태 그대로 남는다."""
    try:
        conn = get_conn(config)
        cur = conn.cursor()
        cur.execute(
            "UPDATE tool_observer_runs SET agent_action = %s WHERE id = %s",
            (agent_action, run_id),
        )
        conn.commit()
        cur.close()
        conn.close()
        return True
    except Exception as e:
        log_warn(f"agent_action 업데이트 실패 (무시 가능): {e}")
        return False


def fetch_recent_runs(config: dict, limit: int = 10) -> list[dict]:
    try:
        conn = get_conn(config)
        cur = conn.cursor()
        cur.execute(
            """
            SELECT run_at, status, changes_count, failed_tools,
                   error_summary, agent_action, observer_exit_code, run_duration_sec
            FROM tool_observer_runs
            ORDER BY run_at DESC
            LIMIT %s
            """,
            (limit,),
        )
        rows = cur.fetchall()
        cur.close()
        conn.close()
    except Exception as e:
        log_err(f"tool_observer_runs 조회 실패: {e}")
        return []

    return [
        {
            "run_at": r[0], "status": r[1], "changes_count": r[2],
            "failed_tools": r[3] or [], "error_summary": r[4],
            "agent_action": r[5], "observer_exit_code": r[6], "run_duration_sec": r[7],
        }
        for r in rows
    ]


def fetch_quarterly_schedule(config: dict) -> list[dict]:
    """DB에서 오늘 이후 분기 일정 조회 (최대 4건) — 이메일 하단 표시용."""
    try:
        conn = get_conn(config)
        cur = conn.cursor()
        cur.execute("""
            SELECT year, quarter, announce_date, required_use_date,
                   cts_next, vts_next, gts_next, notes
            FROM xts_quarterly_schedule
            WHERE required_use_date >= CURRENT_DATE - INTERVAL '30 days'
            ORDER BY year, quarter
            LIMIT 4
        """)
        rows = cur.fetchall()
        cur.close()
        conn.close()
        return [
            {
                "year": r[0], "quarter": r[1],
                "announce_date": r[2], "required_use_date": r[3],
                "cts_next": r[4], "vts_next": r[5], "gts_next": r[6], "notes": r[7],
            }
            for r in rows
        ]
    except Exception as e:
        log_warn(f"분기별 일정 조회 실패: {e}")
        return []

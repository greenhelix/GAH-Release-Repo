#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""
Tool Observer 핵심 타입.

실행 결과를 "코드가 직접, 결정적으로" 판정하기 위한 자료구조 — Claude가 로그
텍스트를 읽고 상태를 추측하는 방식(구 agent_runner.py Phase 2)을 대체한다.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Awaitable, Callable


class ToolOutcome(str, Enum):
    OK = "ok"
    EXTRACTION_FAILED = "extraction_failed"  # 값이 전부 미발견 (auth_required 무관하게 적용)
    AUTH_FAILED = "auth_failed"              # auth_required 대상에서 값이 전부 미발견
    SKIPPED = "skipped"                      # 세션 사전확인 실패로 스크래핑 자체를 건너뜀


@dataclass
class ExtractionResult:
    tool_id: str
    checked_at: str
    last_updated: str | None
    values: dict[str, Any]
    outcome: ToolOutcome = ToolOutcome.OK
    error: str | None = None
    # android_key → 사이트에 명시된 실제 릴리즈 날짜(YYYY-MM-DD, 파싱 가능한 경우만).
    # 대부분의 suite는 채우지 않음(빈 dict) — detected_at과 구분되는 released_at 용도.
    release_dates: dict[str, str | None] = field(default_factory=dict)


@dataclass
class ToolDefinition:
    """도구 하나를 등록하는 데 필요한 전부. 새 도구 추가 = 이 타입을 채운
    tools/<id>.py 파일 하나 + tools/__init__.py 한 줄."""
    id: str
    suite_name: str  # xts_tool_versions.suite_name
    extract: Callable[[Any, dict], Awaitable[ExtractionResult]]
    # (android_version 키, 원시 스크래핑값) -> (xts_tool_versions.version 형식 문자열, notes)
    normalize_version: Callable[[str, Any], "tuple[str | None, str | None]"]


@dataclass
class ToolRunOutcome:
    tool_id: str
    tool_name: str
    outcome: ToolOutcome
    extraction: ExtractionResult | None = None
    new_versions: list[tuple[str, str, str | None, str | None]] = field(default_factory=list)
    error: str | None = None


@dataclass
class RunResult:
    started_at: str
    finished_at: str
    duration_sec: float
    dry_run: bool
    tool_outcomes: list[ToolRunOutcome] = field(default_factory=list)
    status: str = "success"
    auth_failed_tools: list[str] = field(default_factory=list)
    extraction_failed_tools: list[str] = field(default_factory=list)
    total_new_versions: int = 0
    email_sent: bool = False
    email_error: str | None = None
    db_write_ok: bool = True
    db_write_error: str | None = None
    exit_code: int = 0

    def to_dict(self) -> dict:
        d = dict(self.__dict__)
        d["tool_outcomes"] = [
            {
                "tool_id": t.tool_id,
                "tool_name": t.tool_name,
                "outcome": t.outcome.value,
                "new_versions": t.new_versions,
                "error": t.error,
            }
            for t in self.tool_outcomes
        ]
        return d

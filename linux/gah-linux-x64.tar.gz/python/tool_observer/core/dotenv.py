#!/usr/bin/env python3
# Python 3.8 호환
from __future__ import annotations

"""
.env.agent 자동 로드 — systemd(EnvironmentFile=)든 사람이 터미널에서 직접
실행하든 항상 같은 방식으로 환경변수가 채워지게 한다.

기존 방식은 systemd만 자동 로드하고, setup_auth.py 등 수동 실행 경로는
`set -a; source .env.agent; set +a`를 사람이 매번 직접 해야 했다 — 이게
빠지는 실수가 반복적으로 발생했다(ANTHROPIC_API_KEY 누락 크래시).

이미 설정된 환경변수(systemd EnvironmentFile= 등)는 절대 덮어쓰지 않는다
(os.environ.setdefault) — 이 파일은 폴백일 뿐, 진짜 환경변수가 항상 우선한다.
"""

import os
from pathlib import Path

REPO_ROOT = Path(__file__).parent.parent.parent.parent
ENV_FILE = REPO_ROOT / ".env.agent"


def load_env_files(path: Path | None = None) -> None:
    """KEY=VALUE 형식의 .env.agent를 os.environ에 setdefault로 로드.
    파일이 없거나 읽기 실패해도 조용히 넘어간다 — 이후 시크릿 해석
    (core/secrets.py)이 값 없음을 별도로 판단한다."""
    target = path or ENV_FILE
    if not target.exists():
        return
    try:
        for line in target.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key:
                os.environ.setdefault(key, value)
    except Exception:
        pass

#!/bin/bash
# Tool Observer 재인증 — 알림 팝업의 "재인증 시작" 클릭 시 실행됨.
# doctor로 먼저 상태를 확인해서 필요한 절차만 진행한다.
cd "$(dirname "$0")"

echo "════════════════════════════════════════"
echo " Tool Observer 재인증"
echo "════════════════════════════════════════"
echo
echo "[1/2] 현재 상태 확인 중..."
DOCTOR_OUT=$(./venv/bin/python cli.py doctor 2>&1)
echo "$DOCTOR_OUT" | sed -n '/==== DOCTOR ====/,/====$/p'

if echo "$DOCTOR_OUT" | grep -q "FAIL"; then
    echo
    echo "→ 세션 만료 감지. 브라우저 창이 열리면 구글 계정으로 로그인 후,"
    echo "  이 터미널로 돌아와 Enter를 눌러주세요."
    echo
    ./venv/bin/python setup_auth.py
else
    echo
    echo "→ 세션은 정상입니다. Gmail 토큰만 확인합니다."
    echo "  (토큰이 만료된 경우 인증 브라우저 창이 열립니다)"
    echo
    ./venv/bin/python cli.py test-email
fi

echo
echo "[2/2] 최종 확인"
./venv/bin/python cli.py doctor

echo
echo "════════════════════════════════════════"
read -n1 -s -r -p "완료되었습니다. 아무 키나 누르면 창이 닫힙니다."
echo
